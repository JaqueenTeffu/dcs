    <?php $__env->startSection('meta'); ?>
        <title>Leave Types | Workday Time Clock</title>
        <meta name="description" content="Workday leave type, view leave types, add or edit leave types and export or download leave types.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-import-leavetypes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title uppercase"><?php echo e(__("Add Leave Types")); ?>

                    <a href="<?php echo e(url('fields/leavetype/leave-groups')); ?>" class="ui primary mini button offsettop5 float-right"><i class="icon calendar check outline"></i><?php echo e(__("Leave Groups")); ?></a>
                    <button class="ui basic button mini offsettop5 btn-import float-right"><i class="ui icon upload"></i><?php echo e(__("Import")); ?></button>
                    <a href="<?php echo e(url('export/fields/leavetypes' )); ?>" class="ui basic button mini offsettop5 btm-export float-right"><i class="ui icon download"></i><?php echo e(__("Export")); ?></a>
                </h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="box box-success">
                    <div class="box-body">
                        <?php if($errors->any()): ?>
                        <div class="ui error message">
                            <i class="close icon"></i>
                            <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                            <ul class="list">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <form id="add_leavetype_form" action="<?php echo e(url('fields/leavetype/add')); ?>" class="ui form" method="post" accept-charset="utf-8">
                            <?php echo csrf_field(); ?>
                            <div class="field">
                                <label><?php echo e(__("Leave Name")); ?> <span class="help">e.g. "Vacation Leave, Sick Leave"</span></label>
                                <input class="uppercase" name="leavetype" value="" type="text">
                            </div>
                            <div class="field">
                                <label><?php echo e(__("Credits")); ?> <span class="help">e.g. "15" (days)</span></label>
                                <input class="" name="credits" value="" type="text">
                            </div>
                            <div class="grouped fields opt-radio">
                                <label class=""><?php echo e(__("Choose Term")); ?></label>
                                <div class="field">
                                    <div class="ui radio checkbox">
                                        <input type="radio" name="term" value="Monthly" checked="checked">
                                        <label><?php echo e(__("Monthly")); ?></label>
                                    </div>
                                </div>
                                <div class="field" style="padding:0px!important">
                                    <div class="ui radio checkbox">
                                        <input type="radio" name="term" value="Yearly">
                                        <label><?php echo e(__("Yearly")); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="field">
                                <div class="ui error message">
                                    <i class="close icon"></i>
                                    <div class="header"></div>
                                    <ul class="list">
                                        <li class=""></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="actions">
                                <button type="submit" class="ui positive button small"><i class="ui icon check"></i> <?php echo e(__("Save")); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="box box-success">
                    <div class="box-body">
                        <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th><?php echo e(__("Description")); ?></th>
                                    <th><?php echo e(__("Credits")); ?></th>
                                    <th><?php echo e(__("Term")); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($data)): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leavetype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($leavetype->leavetype); ?></td>
                                    <td><?php echo e($leavetype->limit); ?></td>
                                    <td><?php echo e($leavetype->percalendar); ?></td>
                                    <td class="align-right"><a href="<?php echo e(url('fields/leavetype/delete/'.$leavetype->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});

    function validateFile() {
        var f = document.getElementById("csvfile").value;
        var d = f.lastIndexOf(".") + 1;
        var ext = f.substr(d, f.length).toLowerCase();
        if (ext == "csv") {} else {
            document.getElementById("csvfile").value = "";
            $.notify({
                icon: 'ui icon times',
                message: "Please upload only CSV file format."
            }, {
                type: 'danger',
                timer: 400
            });
        }
    }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/fields/leavetype.blade.php ENDPATH**/ ?>