<div class="ui modal tiny import">
    <div class="header"><?php echo e(__("Import Company")); ?></div>
    <div class="content">
    <form action="<?php echo e(url('import/fields/company')); ?>" class="ui form" method="post" accept-charset="utf-8"enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <div class="field">
            <label><?php echo e(__("Import CSV file")); ?></label>
            <input class="ui file upload" value="" id="csvfile" name="csv" type="file" accept=".csv" onchange="validateFile()">
        </div>
    </div>
    <div class="actions">
        <button class="ui positive button approve" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Submit")); ?></button>
        <button class="ui grey button cancel" type="button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></button>
    </div>
    </form>  
</div>
<?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/modals/modal-import-company.blade.php ENDPATH**/ ?>