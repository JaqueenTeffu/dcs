    <?php $__env->startSection('meta'); ?>
        <title>Leave Groups | Workday Time Clock</title>
        <meta name="description" content="Workday leave groups, view leave groups, add leave groups, and edit leave groups.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-add-leavegroup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__("Leave Groups")); ?>

                <button class="ui positive mini button offsettop5 btn-add float-right"><i class="ui icon plus"></i><?php echo e(__("Add")); ?></button>
                <a href="<?php echo e(url('fields/leavetype/')); ?>" class="ui basic mini button offsettop5 float-right"><i class="icon angle left"></i><?php echo e(__("Return")); ?></a>
            </h2>
        </div>

        <div class="row">
            <?php if($errors->any()): ?>
            <div class="ui fluid error message">
                <i class="close icon"></i>
                <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                <ul class="list">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th><?php echo e(__("Leave Group")); ?></th>
                                <th><?php echo e(__("Description")); ?></th>
                                <th><?php echo e(__("Privilege")); ?></th>
                                <th><?php echo e(__("Status")); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($lg)): ?> 
                                <?php $__currentLoopData = $lg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($l->leavegroup); ?></td>
                                        <td><?php echo e($l->description); ?></td>
                                        <td>
                                            <?php if(isset($lt)): ?>
                                                <?php $__currentLoopData = $lt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <?php
                                                        $lgroup = explode(",",$l->leaveprivileges);
                                                        foreach ($lgroup as $v) 
                                                        {
                                                            if($v == $ln->id)
                                                            {
                                                                echo $ln->leavetype.", ";
                                                            }
                                                        }
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php if($l->status == 1): ?> Active <?php else: ?> Disabled <?php endif; ?></td>
                                        <td class="align-right">
                                            <a href="<?php echo e(url('fields/leavetype/leave-groups/edit/'.$l->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                            <a href="<?php echo e(url('fields/leavetype/leave-groups/delete/'.$l->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outlin"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/fields/leave-groups.blade.php ENDPATH**/ ?>