    <?php $__env->startSection('meta'); ?>
        <title>Profile | Workday Time Clock</title>
        <meta name="description" content="Workday view employee profile, edit employee profile, update employee profile">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__('Employee Profile')); ?>

                    <a href="<?php echo e(url('employees')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i><?php echo e(__('Return')); ?></a>
                </h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-md-4 float-left">
                <div class="box box-success">
                    <div class="box-body employee-info">
                        <div class="author">
                        <?php if($i != null): ?>
                            <img class="avatar border-white" src="<?php echo e(asset('/assets/faces/'.$i)); ?>" alt="profile photo"/>
                        <?php else: ?>
                            <img class="avatar border-white" src="<?php echo e(asset('/assets/images/faces/default_user.jpg')); ?>" alt="profile photo"/>
                        <?php endif; ?>
                        </div>
                        <p class="description text-center">
                            <h4 class="title"><?php if(isset($p->firstname)): ?> <?php echo e($p->firstname); ?> <?php endif; ?> <?php if(isset($p->lastname)): ?> <?php echo e($p->lastname); ?> <?php endif; ?></h4>
                            <table style="width: 100%" class="profile-tbl">
                                <tbody>
                                    <tr>
                                        <td><?php echo e(__('Email')); ?></td>
                                        <td><span class="p_value"><?php if(isset($p->emailaddress)): ?> <?php echo e($p->emailaddress); ?> <?php endif; ?></span></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Mobile no.')); ?></td>
                                        <td><span class="p_value"><?php if(isset($p->mobileno)): ?> <?php echo e($p->mobileno); ?> <?php endif; ?></span></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('ID no.')); ?></td>
                                        <td><span class="p_value"><?php if(isset($c->idno)): ?> <?php echo e($c->idno); ?> <?php endif; ?></span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-8 float-left">
                <div class="box box-success">
                    <div class="box-header with-border"><?php echo e(__('Personal Information')); ?></div>
                    <div class="box-body employee-info">
                            <table class="tablelist">
                                <tbody>
                                    <tr>
                                        <td><p><?php echo e(__('Civil Status')); ?></p></td>
                                        <td><p><?php if(isset($p->civilstatus)): ?> <?php echo e($p->civilstatus); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Age')); ?></p></td>
                                        <td><p><?php if(isset($p->age)): ?> <?php echo e($p->age); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Height')); ?> <span class="help">(cm)</span></p></td>
                                        <td><p><?php if(isset($p->height)): ?> <?php echo e($p->height); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Weight')); ?> <span class="help">(pounds)</span></p></td>
                                        <td><p><?php if(isset($p->weight)): ?> <?php echo e($p->weight); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Gender')); ?></p></td>
                                        <td><p><?php if(isset($p->gender)): ?> <?php echo e($p->gender); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Date of Birth')); ?></p></td>
                                        <td>
                                            <p>
                                                <?php if(isset($p->birthday)): ?> 
                                                    <?php echo e(date("F d, Y", strtotime($p->birthday))) ?>
                                                <?php endif; ?>
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Place of Birth')); ?></p></td>
                                        <td><p><?php if(isset($p->birthplace)): ?> <?php echo e($p->birthplace); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Home Address')); ?></p></td>
                                        <td><p><?php if(isset($p->homeaddress)): ?> <?php echo e($p->homeaddress); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('National ID')); ?></p></td>
                                        <td><p><?php if(isset($p->nationalid)): ?> <?php echo e($p->nationalid); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <h4 class="ui dividing header"><?php echo e(__('Designation')); ?></h4>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Company')); ?></td>
                                        <td><?php if(isset($c->company)): ?> <?php echo e($c->company); ?> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Department')); ?></p></td>
                                        <td><p><?php if(isset($c->department)): ?> <?php echo e($c->department); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Position')); ?></td>
                                        <td><?php if(isset($c->jobposition)): ?> <?php echo e($c->jobposition); ?> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Leave Privilege')); ?></td>
                                        <td>
                                            <?php if(isset($leavetype)): ?>
                                                <?php if(isset($leavegroup)): ?> 
                                                    <?php if(isset($c->leaveprivilege)): ?>
                                                        <?php $__currentLoopData = $leavegroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($lg->id == $c->leaveprivilege): ?>
                                                                <?php
                                                                    $lp = explode(",", $lg->leaveprivileges);
                                                                ?>
                                                                <?php $__currentLoopData = $lp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rights): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                    <?php $__currentLoopData = $leavetype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($lt->id == $rights): ?> <?php echo e($lt->leavetype); ?>, <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Employment Type')); ?></p></td>
                                        <td><p><?php if(isset($p->employmenttype)): ?> <?php echo e($p->employmenttype); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Employement Status')); ?></p></td>
                                        <td><p><?php if(isset($p->employmentstatus)): ?> <?php echo e($p->employmentstatus); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Official Start Date')); ?></p></td>
                                        <td>
                                            <p>
                                            <?php if(isset($c->startdate)): ?> 
                                                <?php echo e(date("F d, Y", strtotime($c->startdate))) ?>
                                            <?php endif; ?>
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><p><?php echo e(__('Date Regularized')); ?></p></td>
                                        <td>
                                            <p>
                                            <?php if(isset($c->dateregularized)): ?> 
                                                <?php echo e(date("F d, Y", strtotime($c->dateregularized))) ?>
                                            <?php endif; ?>
                                            </p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    






<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/profile-view.blade.php ENDPATH**/ ?>