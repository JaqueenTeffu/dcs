<div class="ui modal medium add">
    <div class="header"><?php echo e(__("Add Employee Attendance")); ?></div>
    <div class="content">
        <form id="add_attendance_form" action="<?php echo e(url('attendance/add-entry')); ?>" class="ui form add-attendance" method="post" accept-charset="utf-8">
        <?php echo csrf_field(); ?>
        <div class="field">
            <label><?php echo e(__("Employee")); ?></label>
            <select class="ui search dropdown getref uppercase" name="name">
                <option value="">Select Employee</option>
                <?php if(isset($employees)): ?>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?>" data-ref="<?php echo e($data->id); ?>"><?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="field">
            <label for=""><?php echo e(__("Date")); ?></label>
            <input class="airdatepicker" type="text" placeholder="0000-00-00" name="date" data-position="top right">
        </div>
        <div class="field">
            <label for=""><?php echo e(__("Time IN")); ?> <span class="help">(required)</span></label>
            <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timein" value="" required>
        </div>
        <div class="field">
            <label for=""><?php echo e(__("Time OUT")); ?> <span class="help">(optional)</span></label>
            <input class="jtimepicker" type="text" placeholder="00:00:00 PM" name="timeout" value="">
        </div>
        <div class="field">
            <div class="ui error message">
                <i class="close icon"></i>
                <div class="header"></div>
                <ul class="list">
                    <li class=""></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="actions">
        <input type="hidden" value="" name="ref">
        <button class="ui positive approve small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Save")); ?></button>
        <button class="ui grey cancel small button" type="button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></button>
    </div>
    </form>
</div><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/modals/modal-add-attendance.blade.php ENDPATH**/ ?>