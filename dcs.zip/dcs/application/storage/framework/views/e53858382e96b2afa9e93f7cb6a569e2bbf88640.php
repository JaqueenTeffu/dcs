    <?php $__env->startSection('meta'); ?>
        <title>General Settings | Workday Time Clock</title>
        <meta name="description" content="Workday settings, view and update system settings.">
    <?php $__env->stopSection(); ?> 
    
    <?php $__env->startSection('styles'); ?>
        <script>var admin = true;</script>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__("General Settings")); ?></h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-md-12">

            <div class="box box-success">
                <div class="box-body">
                            
                    <div class="ui secondary blue pointing tabular menu">
                        <a class="item active" data-tab="system"><?php echo e(__("System")); ?></a>
                        <a class="item" data-tab="about"><?php echo e(__("About")); ?></a>
                        <a class="item" data-tab="attribution"><?php echo e(__("Attributions")); ?></a>
                    </div>
                    
                    <div class="ui tab active" data-tab="system">
                        <div class="col-md-12">
                            <div class="tab-content">
                                    <?php if($errors->any()): ?>
                                    <div class="ui error message">
                                        <i class="close icon"></i>
                                        <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                                        <ul class="list">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                    <form action="<?php echo e(url('settings/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                                    <div class="content">
                                        <?php echo csrf_field(); ?>
                                            <h4 class="ui dividing header"><?php echo e(__("Localization")); ?></h4>

                                            <div class="eight wide field">
                                                <h2 class="ui small header"><?php echo e(__("Country")); ?>

                                                    <div class="sub header"><?php echo e(__("Select your country to enable country specific features")); ?></div>
                                                </h2>
                                                <select name="country" class="ui search dropdown uppercase">
                                                    <option value="">Select Country</option>
                                                    <option value="Afganistan" <?php if($data->country == "Afganistan"): ?> selected <?php endif; ?>>Afghanistan</option>
                                                    <option value="Albania" <?php if($data->country == "Albania"): ?> selected <?php endif; ?>>Albania</option>
                                                    <option value="Algeria" <?php if($data->country == "Algeria"): ?> selected <?php endif; ?>>Algeria</option>
                                                    <option value="American Samoa" <?php if($data->country == "American Samoa"): ?> selected <?php endif; ?>>American Samoa</option>
                                                    <option value="Andorra" <?php if($data->country == "Andorra"): ?> selected <?php endif; ?>>Andorra</option>
                                                    <option value="Angola" <?php if($data->country == "Angola"): ?> selected <?php endif; ?>>Angola</option>
                                                    <option value="Anguilla" <?php if($data->country == "Anguilla"): ?> selected <?php endif; ?>>Anguilla</option>
                                                    <option value="Antigua &amp; Barbuda" <?php if($data->country == "Antigua &amp; Barbuda"): ?> selected <?php endif; ?>>Antigua &amp; Barbuda</option>
                                                    <option value="Argentina" <?php if($data->country == "Argentina"): ?> selected <?php endif; ?>>Argentina</option>
                                                    <option value="Armenia" <?php if($data->country == "Armenia"): ?> selected <?php endif; ?>>Armenia</option>
                                                    <option value="Aruba" <?php if($data->country == "Aruba"): ?> selected <?php endif; ?>>Aruba</option>
                                                    <option value="Australia" <?php if($data->country == "Australia"): ?> selected <?php endif; ?>>Australia</option>
                                                    <option value="Austria" <?php if($data->country == "Austria"): ?> selected <?php endif; ?>>Austria</option>
                                                    <option value="Azerbaijan" <?php if($data->country == "Azerbaijan"): ?> selected <?php endif; ?>>Azerbaijan</option>
                                                    <option value="Bahamas" <?php if($data->country == "Bahamas"): ?> selected <?php endif; ?>>Bahamas</option>
                                                    <option value="Bahrain" <?php if($data->country == "Bahrain"): ?> selected <?php endif; ?>>Bahrain</option>
                                                    <option value="Bangladesh" <?php if($data->country == "Bangladesh"): ?> selected <?php endif; ?>>Bangladesh</option>
                                                    <option value="Barbados" <?php if($data->country == "Barbados"): ?> selected <?php endif; ?>>Barbados</option>
                                                    <option value="Belarus" <?php if($data->country == "Belarus"): ?> selected <?php endif; ?>>Belarus</option>
                                                    <option value="Belgium" <?php if($data->country == "Belgium"): ?> selected <?php endif; ?>>Belgium</option>
                                                    <option value="Belize" <?php if($data->country == "Belize"): ?> selected <?php endif; ?>>Belize</option>
                                                    <option value="Benin" <?php if($data->country == "Benin"): ?> selected <?php endif; ?>>Benin</option>
                                                    <option value="Bermuda" <?php if($data->country == "Bermuda"): ?> selected <?php endif; ?>>Bermuda</option>
                                                    <option value="Bhutan" <?php if($data->country == "Bhutan"): ?> selected <?php endif; ?>>Bhutan</option>
                                                    <option value="Bolivia" <?php if($data->country == "Bolivia"): ?> selected <?php endif; ?>>Bolivia</option>
                                                    <option value="Bonaire" <?php if($data->country == "Bonaire"): ?> selected <?php endif; ?>>Bonaire</option>
                                                    <option value="Bosnia &amp; Herzegovina" <?php if($data->country == "Bosnia &amp; Herzegovina"): ?> selected <?php endif; ?>>Bosnia &amp; Herzegovina</option>
                                                    <option value="Botswana" <?php if($data->country == "Botswana"): ?> selected <?php endif; ?>>Botswana</option>
                                                    <option value="Brazil" <?php if($data->country == "Brazil"): ?> selected <?php endif; ?>>Brazil</option>
                                                    <option value="British Indian Ocean Ter" <?php if($data->country == "British Indian Ocean Ter"): ?> selected <?php endif; ?>>British Indian Ocean Ter</option>
                                                    <option value="Brunei" <?php if($data->country == "Brunei"): ?> selected <?php endif; ?>>Brunei</option>
                                                    <option value="Bulgaria" <?php if($data->country == "Bulgaria"): ?> selected <?php endif; ?>>Bulgaria</option>
                                                    <option value="Burkina Faso" <?php if($data->country == "Burkina Faso"): ?> selected <?php endif; ?>>Burkina Faso</option>
                                                    <option value="Burundi" <?php if($data->country == "Burundi"): ?> selected <?php endif; ?>>Burundi</option>
                                                    <option value="Cambodia" <?php if($data->country == "Cambodia"): ?> selected <?php endif; ?>>Cambodia</option>
                                                    <option value="Cameroon" <?php if($data->country == "Cameroon"): ?> selected <?php endif; ?>>Cameroon</option>
                                                    <option value="Canada" <?php if($data->country == "Canada"): ?> selected <?php endif; ?>>Canada</option>
                                                    <option value="Canary Islands" <?php if($data->country == "Canary Islands"): ?> selected <?php endif; ?>>Canary Islands</option>
                                                    <option value="Cape Verde" <?php if($data->country == "Cape Verde"): ?> selected <?php endif; ?>>Cape Verde</option>
                                                    <option value="Cayman Islands" <?php if($data->country == "Cayman Islands"): ?> selected <?php endif; ?>>Cayman Islands</option>
                                                    <option value="Central African Republic" <?php if($data->country == "Central African Republic"): ?> selected <?php endif; ?>>Central African Republic</option>
                                                    <option value="Chad" <?php if($data->country == "Chad"): ?> selected <?php endif; ?>>Chad</option>
                                                    <option value="Channel Islands" <?php if($data->country == "Channel Islands"): ?> selected <?php endif; ?>>Channel Islands</option>
                                                    <option value="Chile" <?php if($data->country == "Chile"): ?> selected <?php endif; ?>>Chile</option>
                                                    <option value="China" <?php if($data->country == "China"): ?> selected <?php endif; ?>>China</option>
                                                    <option value="Christmas Island" <?php if($data->country == "Christmas Island"): ?> selected <?php endif; ?>>Christmas Island</option>
                                                    <option value="Cocos Island" <?php if($data->country == "Cocos Island"): ?> selected <?php endif; ?>>Cocos Island</option>
                                                    <option value="Colombia" <?php if($data->country == "Colombia"): ?> selected <?php endif; ?>>Colombia</option>
                                                    <option value="Comoros" <?php if($data->country == "Comoros"): ?> selected <?php endif; ?>>Comoros</option>
                                                    <option value="Congo" <?php if($data->country == "Congo"): ?> selected <?php endif; ?>>Congo</option>
                                                    <option value="Cook Islands" <?php if($data->country == "Cook Islands"): ?> selected <?php endif; ?>>Cook Islands</option>
                                                    <option value="Costa Rica" <?php if($data->country == "Costa Rica"): ?> selected <?php endif; ?>>Costa Rica</option>
                                                    <option value="Cote DIvoire" <?php if($data->country == "Cote DIvoire"): ?> selected <?php endif; ?>>Cote DIvoire</option>
                                                    <option value="Croatia" <?php if($data->country == "Croatia"): ?> selected <?php endif; ?>>Croatia</option>
                                                    <option value="Cuba" <?php if($data->country == "Cuba"): ?> selected <?php endif; ?>>Cuba</option>
                                                    <option value="Curaco" <?php if($data->country == "Curaco"): ?> selected <?php endif; ?>>Curacao</option>
                                                    <option value="Cyprus" <?php if($data->country == "Cyprus"): ?> selected <?php endif; ?>>Cyprus</option>
                                                    <option value="Czech Republic" <?php if($data->country == "Czech Republic"): ?> selected <?php endif; ?>>Czech Republic</option>
                                                    <option value="Denmark" <?php if($data->country == "Denmark"): ?> selected <?php endif; ?>>Denmark</option>
                                                    <option value="Djibouti" <?php if($data->country == "Djibouti"): ?> selected <?php endif; ?>>Djibouti</option>
                                                    <option value="Dominica" <?php if($data->country == "Dominica"): ?> selected <?php endif; ?>>Dominica</option>
                                                    <option value="Dominican Republic" <?php if($data->country == "Dominican Republic"): ?> selected <?php endif; ?>>Dominican Republic</option>
                                                    <option value="East Timor" <?php if($data->country == "East Timor"): ?> selected <?php endif; ?>>East Timor</option>
                                                    <option value="Ecuador" <?php if($data->country == "Ecuador"): ?> selected <?php endif; ?>>Ecuador</option>
                                                    <option value="Egypt" <?php if($data->country == "Egypt"): ?> selected <?php endif; ?>>Egypt</option>
                                                    <option value="El Salvador" <?php if($data->country == "El Salvador"): ?> selected <?php endif; ?>>El Salvador</option>
                                                    <option value="Equatorial Guinea" <?php if($data->country == "Equatorial Guinea"): ?> selected <?php endif; ?>>Equatorial Guinea</option>
                                                    <option value="Eritrea" <?php if($data->country == "Eritrea"): ?> selected <?php endif; ?>>Eritrea</option>
                                                    <option value="Estonia" <?php if($data->country == "Estonia"): ?> selected <?php endif; ?>>Estonia</option>
                                                    <option value="Ethiopia" <?php if($data->country == "Ethiopia"): ?> selected <?php endif; ?>>Ethiopia</option>
                                                    <option value="Falkland Islands" <?php if($data->country == "Falkland Islands"): ?> selected <?php endif; ?>>Falkland Islands</option>
                                                    <option value="Faroe Islands" <?php if($data->country == "Faroe Islands"): ?> selected <?php endif; ?>>Faroe Islands</option>
                                                    <option value="Fiji" <?php if($data->country == "Fiji"): ?> selected <?php endif; ?>>Fiji</option>
                                                    <option value="Finland" <?php if($data->country == "Finland"): ?> selected <?php endif; ?>>Finland</option>
                                                    <option value="France" <?php if($data->country == "France"): ?> selected <?php endif; ?>>France</option>
                                                    <option value="French Guiana" <?php if($data->country == "French Guiana"): ?> selected <?php endif; ?>>French Guiana</option>
                                                    <option value="French Polynesia" <?php if($data->country == "French Polynesia"): ?> selected <?php endif; ?>>French Polynesia</option>
                                                    <option value="French Southern Ter" <?php if($data->country == "French Southern Ter"): ?> selected <?php endif; ?>>French Southern Ter</option>
                                                    <option value="Gabon" <?php if($data->country == "Gabon"): ?> selected <?php endif; ?>>Gabon</option>
                                                    <option value="Gambia" <?php if($data->country == "Gambia"): ?> selected <?php endif; ?>>Gambia</option>
                                                    <option value="Georgia" <?php if($data->country == "Georgia"): ?> selected <?php endif; ?>>Georgia</option>
                                                    <option value="Germany" <?php if($data->country == "Germany"): ?> selected <?php endif; ?>>Germany</option>
                                                    <option value="Ghana" <?php if($data->country == "Ghana"): ?> selected <?php endif; ?>>Ghana</option>
                                                    <option value="Gibraltar" <?php if($data->country == "Gibraltar"): ?> selected <?php endif; ?>>Gibraltar</option>
                                                    <option value="Great Britain" <?php if($data->country == "Great Britain"): ?> selected <?php endif; ?>>Great Britain</option>
                                                    <option value="Greece" <?php if($data->country == "Greece"): ?> selected <?php endif; ?>>Greece</option>
                                                    <option value="Greenland" <?php if($data->country == "Greenland"): ?> selected <?php endif; ?>>Greenland</option>
                                                    <option value="Grenada" <?php if($data->country == "Grenada"): ?> selected <?php endif; ?>>Grenada</option>
                                                    <option value="Guadeloupe" <?php if($data->country == "Guadeloupe"): ?> selected <?php endif; ?>>Guadeloupe</option>
                                                    <option value="Guam" <?php if($data->country == "Guam"): ?> selected <?php endif; ?>>Guam</option>
                                                    <option value="Guatemala" <?php if($data->country == "Guatemala"): ?> selected <?php endif; ?>>Guatemala</option>
                                                    <option value="Guinea" <?php if($data->country == "Guinea"): ?> selected <?php endif; ?>>Guinea</option>
                                                    <option value="Guyana" <?php if($data->country == "Guyana"): ?> selected <?php endif; ?>>Guyana</option>
                                                    <option value="Haiti" <?php if($data->country == "Haiti"): ?> selected <?php endif; ?>>Haiti</option>
                                                    <option value="Hawaii" <?php if($data->country == "Hawaii"): ?> selected <?php endif; ?>>Hawaii</option>
                                                    <option value="Honduras" <?php if($data->country == "Honduras"): ?> selected <?php endif; ?>>Honduras</option>
                                                    <option value="Hong Kong" <?php if($data->country == "Hong Kong"): ?> selected <?php endif; ?>>Hong Kong</option>
                                                    <option value="Hungary" <?php if($data->country == "Hungary"): ?> selected <?php endif; ?>>Hungary</option>
                                                    <option value="Iceland" <?php if($data->country == "Iceland"): ?> selected <?php endif; ?>>Iceland</option>
                                                    <option value="India" <?php if($data->country == "India"): ?> selected <?php endif; ?>>India</option>
                                                    <option value="Indonesia" <?php if($data->country == "Indonesia"): ?> selected <?php endif; ?>>Indonesia</option>
                                                    <option value="Iran" <?php if($data->country == "Iran"): ?> selected <?php endif; ?>>Iran</option>
                                                    <option value="Iraq" <?php if($data->country == "Iraq"): ?> selected <?php endif; ?>>Iraq</option>
                                                    <option value="Ireland" <?php if($data->country == "Ireland"): ?> selected <?php endif; ?>>Ireland</option>
                                                    <option value="Isle of Man" <?php if($data->country == "Isle of Man"): ?> selected <?php endif; ?>>Isle of Man</option>
                                                    <option value="Israel" <?php if($data->country == "Israel"): ?> selected <?php endif; ?>>Israel</option>
                                                    <option value="Italy" <?php if($data->country == "Italy"): ?> selected <?php endif; ?>>Italy</option>
                                                    <option value="Jamaica" <?php if($data->country == "Jamaica"): ?> selected <?php endif; ?>>Jamaica</option>
                                                    <option value="Japan" <?php if($data->country == "Japan"): ?> selected <?php endif; ?>>Japan</option>
                                                    <option value="Jordan" <?php if($data->country == "Jordan"): ?> selected <?php endif; ?>>Jordan</option>
                                                    <option value="Kazakhstan" <?php if($data->country == "Kazakhstan"): ?> selected <?php endif; ?>>Kazakhstan</option>
                                                    <option value="Kenya" <?php if($data->country == "Kenya"): ?> selected <?php endif; ?>>Kenya</option>
                                                    <option value="Kiribati" <?php if($data->country == "Kiribati"): ?> selected <?php endif; ?>>Kiribati</option>
                                                    <option value="Korea North" <?php if($data->country == "Korea North"): ?> selected <?php endif; ?>>Korea North</option>
                                                    <option value="Korea Sout" <?php if($data->country == "Korea Sout"): ?> selected <?php endif; ?>>Korea South</option>
                                                    <option value="Kuwait" <?php if($data->country == "Kuwait"): ?> selected <?php endif; ?>>Kuwait</option>
                                                    <option value="Kyrgyzstan" <?php if($data->country == "Kyrgyzstan"): ?> selected <?php endif; ?>>Kyrgyzstan</option>
                                                    <option value="Laos" <?php if($data->country == "Laos"): ?> selected <?php endif; ?>>Laos</option>
                                                    <option value="Latvia" <?php if($data->country == "Latvia"): ?> selected <?php endif; ?>>Latvia</option>
                                                    <option value="Lebanon" <?php if($data->country == "Lebanon"): ?> selected <?php endif; ?>>Lebanon</option>
                                                    <option value="Lesotho" <?php if($data->country == "Lesotho"): ?> selected <?php endif; ?>>Lesotho</option>
                                                    <option value="Liberia" <?php if($data->country == "Liberia"): ?> selected <?php endif; ?>>Liberia</option>
                                                    <option value="Libya" <?php if($data->country == "Libya"): ?> selected <?php endif; ?>>Libya</option>
                                                    <option value="Liechtenstein" <?php if($data->country == "Liechtenstein"): ?> selected <?php endif; ?>>Liechtenstein</option>
                                                    <option value="Lithuania" <?php if($data->country == "Lithuania"): ?> selected <?php endif; ?>>Lithuania</option>
                                                    <option value="Luxembourg" <?php if($data->country == "Luxembourg"): ?> selected <?php endif; ?>>Luxembourg</option>
                                                    <option value="Macau" <?php if($data->country == "Macau"): ?> selected <?php endif; ?>>Macau</option>
                                                    <option value="Macedonia" <?php if($data->country == "Macedonia"): ?> selected <?php endif; ?>>Macedonia</option>
                                                    <option value="Madagascar" <?php if($data->country == "Madagascar"): ?> selected <?php endif; ?>>Madagascar</option>
                                                    <option value="Malaysia" <?php if($data->country == "Malaysia"): ?> selected <?php endif; ?>>Malaysia</option>
                                                    <option value="Malawi" <?php if($data->country == "Malawi"): ?> selected <?php endif; ?>>Malawi</option>
                                                    <option value="Maldives" <?php if($data->country == "Maldives"): ?> selected <?php endif; ?>>Maldives</option>
                                                    <option value="Mali" <?php if($data->country == "Mali"): ?> selected <?php endif; ?>>Mali</option>
                                                    <option value="Malta" <?php if($data->country == "Malta"): ?> selected <?php endif; ?>>Malta</option>
                                                    <option value="Marshall Islands" <?php if($data->country == "Marshall Islands"): ?> selected <?php endif; ?>>Marshall Islands</option>
                                                    <option value="Martinique" <?php if($data->country == "Martinique"): ?> selected <?php endif; ?>>Martinique</option>
                                                    <option value="Mauritania" <?php if($data->country == "Mauritania"): ?> selected <?php endif; ?>>Mauritania</option>
                                                    <option value="Mauritius" <?php if($data->country == "Mauritius"): ?> selected <?php endif; ?>>Mauritius</option>
                                                    <option value="Mayotte" <?php if($data->country == "Mayotte"): ?> selected <?php endif; ?>>Mayotte</option>
                                                    <option value="Mexico" <?php if($data->country == "Mexico"): ?> selected <?php endif; ?>>Mexico</option>
                                                    <option value="Midway Islands" <?php if($data->country == "Midway Islands"): ?> selected <?php endif; ?>>Midway Islands</option>
                                                    <option value="Moldova" <?php if($data->country == "Moldova"): ?> selected <?php endif; ?>>Moldova</option>
                                                    <option value="Monaco" <?php if($data->country == "Monaco"): ?> selected <?php endif; ?>>Monaco</option>
                                                    <option value="Mongolia" <?php if($data->country == "Mongolia"): ?> selected <?php endif; ?>>Mongolia</option>
                                                    <option value="Montserrat" <?php if($data->country == "Montserrat"): ?> selected <?php endif; ?>>Montserrat</option>
                                                    <option value="Morocco" <?php if($data->country == "Morocco"): ?> selected <?php endif; ?>>Morocco</option>
                                                    <option value="Mozambique" <?php if($data->country == "Mozambique"): ?> selected <?php endif; ?>>Mozambique</option>
                                                    <option value="Myanmar" <?php if($data->country == "Myanmar"): ?> selected <?php endif; ?>>Myanmar</option>
                                                    <option value="Nambia" <?php if($data->country == "Nambia"): ?> selected <?php endif; ?>>Nambia</option>
                                                    <option value="Nauru" <?php if($data->country == "Nauru"): ?> selected <?php endif; ?>>Nauru</option>
                                                    <option value="Nepal" <?php if($data->country == "Nepal"): ?> selected <?php endif; ?>>Nepal</option>
                                                    <option value="Netherland Antilles" <?php if($data->country == "Netherland Antilles"): ?> selected <?php endif; ?>>Netherland Antilles</option>
                                                    <option value="Netherlands" <?php if($data->country == "Netherlands"): ?> selected <?php endif; ?>>Netherlands (Holland, Europe)</option>
                                                    <option value="Nevis" <?php if($data->country == "Nevis"): ?> selected <?php endif; ?>>Nevis</option>
                                                    <option value="New Caledonia" <?php if($data->country == "New Caledonia"): ?> selected <?php endif; ?>>New Caledonia</option>
                                                    <option value="New Zealand" <?php if($data->country == "New Zealand"): ?> selected <?php endif; ?>>New Zealand</option>
                                                    <option value="Nicaragua" <?php if($data->country == "Nicaragua"): ?> selected <?php endif; ?>>Nicaragua</option>
                                                    <option value="Niger" <?php if($data->country == "Niger"): ?> selected <?php endif; ?>>Niger</option>
                                                    <option value="Nigeria" <?php if($data->country == "Nigeria"): ?> selected <?php endif; ?>>Nigeria</option>
                                                    <option value="Niue" <?php if($data->country == "Niue"): ?> selected <?php endif; ?>>Niue</option>
                                                    <option value="Norfolk Island" <?php if($data->country == "Norfolk Island"): ?> selected <?php endif; ?>>Norfolk Island</option>
                                                    <option value="Norway" <?php if($data->country == "Norway"): ?> selected <?php endif; ?>>Norway</option>
                                                    <option value="Oman" <?php if($data->country == "Oman"): ?> selected <?php endif; ?>>Oman</option>
                                                    <option value="Pakistan" <?php if($data->country == "Pakistan"): ?> selected <?php endif; ?>>Pakistan</option>
                                                    <option value="Palau Island" <?php if($data->country == "Palau Island"): ?> selected <?php endif; ?>>Palau Island</option>
                                                    <option value="Palestine" <?php if($data->country == "Palestine"): ?> selected <?php endif; ?>>Palestine</option>
                                                    <option value="Panama" <?php if($data->country == "Panama"): ?> selected <?php endif; ?>>Panama</option>
                                                    <option value="Papua New Guinea" <?php if($data->country == "Papua New Guinea"): ?> selected <?php endif; ?>>Papua New Guinea</option>
                                                    <option value="Paraguay" <?php if($data->country == "Paraguay"): ?> selected <?php endif; ?>>Paraguay</option>
                                                    <option value="Peru" <?php if($data->country == "Peru"): ?> selected <?php endif; ?>>Peru</option>
                                                    <option value="Phillipines" <?php if($data->country == "Phillipines"): ?> selected <?php endif; ?>>Philippines</option>
                                                    <option value="Pitcairn Island" <?php if($data->country == "Pitcairn Island"): ?> selected <?php endif; ?>>Pitcairn Island</option>
                                                    <option value="Poland" <?php if($data->country == "Poland"): ?> selected <?php endif; ?>>Poland</option>
                                                    <option value="Portugal" <?php if($data->country == "Portugal"): ?> selected <?php endif; ?>>Portugal</option>
                                                    <option value="Puerto Rico" <?php if($data->country == "Puerto Rico"): ?> selected <?php endif; ?>>Puerto Rico</option>
                                                    <option value="Qatar" <?php if($data->country == "Qatar"): ?> selected <?php endif; ?>>Qatar</option>
                                                    <option value="Republic of Montenegro" <?php if($data->country == "Republic of Montenegro"): ?> selected <?php endif; ?>>Republic of Montenegro</option>
                                                    <option value="Republic of Serbia" <?php if($data->country == "Republic of Serbia"): ?> selected <?php endif; ?>>Republic of Serbia</option>
                                                    <option value="Reunion" <?php if($data->country == "Reunion"): ?> selected <?php endif; ?>>Reunion</option>
                                                    <option value="Romania" <?php if($data->country == "Romania"): ?> selected <?php endif; ?>>Romania</option>
                                                    <option value="Russia" <?php if($data->country == "Russia"): ?> selected <?php endif; ?>>Russia</option>
                                                    <option value="Rwanda" <?php if($data->country == "Rwanda"): ?> selected <?php endif; ?>>Rwanda</option>
                                                    <option value="St Barthelemy" <?php if($data->country == "St Barthelemy"): ?> selected <?php endif; ?>>St Barthelemy</option>
                                                    <option value="St Eustatius" <?php if($data->country == "St Eustatius"): ?> selected <?php endif; ?>>St Eustatius</option>
                                                    <option value="St Helena" <?php if($data->country == "St Helena"): ?> selected <?php endif; ?>>St Helena</option>
                                                    <option value="St Kitts-Nevis" <?php if($data->country == "St Kitts-Nevis"): ?> selected <?php endif; ?>>St Kitts-Nevis</option>
                                                    <option value="St Lucia" <?php if($data->country == "St Lucia"): ?> selected <?php endif; ?>>St Lucia</option>
                                                    <option value="St Maarten" <?php if($data->country == "St Maarten"): ?> selected <?php endif; ?>>St Maarten</option>
                                                    <option value="St Pierre &amp; Miquelon" <?php if($data->country == "St Pierre &amp; Miquelon"): ?> selected <?php endif; ?>>St Pierre &amp; Miquelon</option>
                                                    <option value="St Vincent &amp; Grenadines" <?php if($data->country == "St Vincent &amp; Grenadines"): ?> selected <?php endif; ?>>St Vincent &amp; Grenadines</option>
                                                    <option value="Saipan" <?php if($data->country == "Saipan"): ?> selected <?php endif; ?>>Saipan</option>
                                                    <option value="Samoa" <?php if($data->country == "Samoa"): ?> selected <?php endif; ?>>Samoa</option>
                                                    <option value="Samoa American" <?php if($data->country == "Samoa American"): ?> selected <?php endif; ?>>Samoa American</option>
                                                    <option value="San Marino" <?php if($data->country == "San Marino"): ?> selected <?php endif; ?>>San Marino</option>
                                                    <option value="Sao Tome &amp; Principe" <?php if($data->country == "Sao Tome &amp; Principe"): ?> selected <?php endif; ?>>Sao Tome &amp; Principe</option>
                                                    <option value="Saudi Arabia" <?php if($data->country == "Saudi Arabia"): ?> selected <?php endif; ?>>Saudi Arabia</option>
                                                    <option value="Senegal" <?php if($data->country == "Senegal"): ?> selected <?php endif; ?>>Senegal</option>
                                                    <option value="Serbia" <?php if($data->country == "Serbia"): ?> selected <?php endif; ?>>Serbia</option>
                                                    <option value="Seychelles" <?php if($data->country == "Seychelles"): ?> selected <?php endif; ?>>Seychelles</option>
                                                    <option value="Sierra Leone" <?php if($data->country == "Sierra Leone"): ?> selected <?php endif; ?>>Sierra Leone</option>
                                                    <option value="Singapore" <?php if($data->country == "Singapore"): ?> selected <?php endif; ?>>Singapore</option>
                                                    <option value="Slovakia" <?php if($data->country == "Slovakia"): ?> selected <?php endif; ?>>Slovakia</option>
                                                    <option value="Slovenia" <?php if($data->country == "Slovenia"): ?> selected <?php endif; ?>>Slovenia</option>
                                                    <option value="Solomon Islands" <?php if($data->country == "Solomon Islands"): ?> selected <?php endif; ?>>Solomon Islands</option>
                                                    <option value="Somalia" <?php if($data->country == "Somalia"): ?> selected <?php endif; ?>>Somalia</option>
                                                    <option value="South Africa" <?php if($data->country == "South Africa"): ?> selected <?php endif; ?>>South Africa</option>
                                                    <option value="Spain" <?php if($data->country == "Spain"): ?> selected <?php endif; ?>>Spain</option>
                                                    <option value="Sri Lanka" <?php if($data->country == "Sri Lanka"): ?> selected <?php endif; ?>>Sri Lanka</option>
                                                    <option value="Sudan" <?php if($data->country == "Sudan"): ?> selected <?php endif; ?>>Sudan</option>
                                                    <option value="Suriname" <?php if($data->country == "Suriname"): ?> selected <?php endif; ?>>Suriname</option>
                                                    <option value="Swaziland" <?php if($data->country == "Swaziland"): ?> selected <?php endif; ?>>Swaziland</option>
                                                    <option value="Sweden" <?php if($data->country == "Sweden"): ?> selected <?php endif; ?>>Sweden</option>
                                                    <option value="Switzerland" <?php if($data->country == "Switzerland"): ?> selected <?php endif; ?>>Switzerland</option>
                                                    <option value="Syria" <?php if($data->country == "Syria"): ?> selected <?php endif; ?>>Syria</option>
                                                    <option value="Tahiti" <?php if($data->country == "Tahiti"): ?> selected <?php endif; ?>>Tahiti</option>
                                                    <option value="Taiwan" <?php if($data->country == "Taiwan"): ?> selected <?php endif; ?>>Taiwan</option>
                                                    <option value="Tajikistan" <?php if($data->country == "Tajikistan"): ?> selected <?php endif; ?>>Tajikistan</option>
                                                    <option value="Tanzania" <?php if($data->country == "Tanzania"): ?> selected <?php endif; ?>>Tanzania</option>
                                                    <option value="Thailand" <?php if($data->country == "Thailand"): ?> selected <?php endif; ?>>Thailand</option>
                                                    <option value="Togo" <?php if($data->country == "Togo"): ?> selected <?php endif; ?>>Togo</option>
                                                    <option value="Tokelau" <?php if($data->country == "Tokelau"): ?> selected <?php endif; ?>>Tokelau</option>
                                                    <option value="Tonga" <?php if($data->country == "Tonga"): ?> selected <?php endif; ?>>Tonga</option>
                                                    <option value="Trinidad &amp; Tobago" <?php if($data->country == "Trinidad &amp; Tobago"): ?> selected <?php endif; ?>>Trinidad &amp; Tobago</option>
                                                    <option value="Tunisia" <?php if($data->country == "Tunisia"): ?> selected <?php endif; ?>>Tunisia</option>
                                                    <option value="Turkey" <?php if($data->country == "Turkey"): ?> selected <?php endif; ?>>Turkey</option>
                                                    <option value="Turkmenistan" <?php if($data->country == "Turkmenistan"): ?> selected <?php endif; ?>>Turkmenistan</option>
                                                    <option value="Turks &amp; Caicos Is" <?php if($data->country == "Turks &amp; Caicos Is"): ?> selected <?php endif; ?>>Turks &amp; Caicos Is</option>
                                                    <option value="Tuvalu" <?php if($data->country == "Tuvalu"): ?> selected <?php endif; ?>>Tuvalu</option>
                                                    <option value="Uganda" <?php if($data->country == "Uganda"): ?> selected <?php endif; ?>>Uganda</option>
                                                    <option value="Ukraine" <?php if($data->country == "Ukraine"): ?> selected <?php endif; ?>>Ukraine</option>
                                                    <option value="United Arab Erimates" <?php if($data->country == "United Arab Erimates"): ?> selected <?php endif; ?>>United Arab Emirates</option>
                                                    <option value="United Kingdom" <?php if($data->country == "United Kingdom"): ?> selected <?php endif; ?>>United Kingdom</option>
                                                    <option value="United States of America" <?php if($data->country == "United States of America"): ?> selected <?php endif; ?>>United States of America</option>
                                                    <option value="Uraguay" <?php if($data->country == "Uraguay"): ?> selected <?php endif; ?>>Uruguay</option>
                                                    <option value="Uzbekistan" <?php if($data->country == "Uzbekistan"): ?> selected <?php endif; ?>>Uzbekistan</option>
                                                    <option value="Vanuatu" <?php if($data->country == "Vanuatu"): ?> selected <?php endif; ?>>Vanuatu</option>
                                                    <option value="Vatican City State" <?php if($data->country == "Vatican City State"): ?> selected <?php endif; ?>>Vatican City State</option>
                                                    <option value="Venezuela" <?php if($data->country == "Venezuela"): ?> selected <?php endif; ?>>Venezuela</option>
                                                    <option value="Vietnam" <?php if($data->country == "Vietnam"): ?> selected <?php endif; ?>>Vietnam</option>
                                                    <option value="Virgin Islands (Brit)" <?php if($data->country == "Virgin Islands (Brit)"): ?> selected <?php endif; ?>>Virgin Islands (Brit)</option>
                                                    <option value="Virgin Islands (USA)" <?php if($data->country == "Virgin Islands (USA)"): ?> selected <?php endif; ?>>Virgin Islands (USA)</option>
                                                    <option value="Wake Island" <?php if($data->country == "Wake Island"): ?> selected <?php endif; ?>>Wake Island</option>
                                                    <option value="Wallis &amp; Futana Is" <?php if($data->country == "Wallis &amp; Futana Is"): ?> selected <?php endif; ?>>Wallis &amp; Futana Is</option>
                                                    <option value="Yemen" <?php if($data->country == "Yemen"): ?> selected <?php endif; ?>>Yemen</option>
                                                    <option value="Zaire" <?php if($data->country == "Zaire"): ?> selected <?php endif; ?>>Zaire</option>
                                                    <option value="Zambia" <?php if($data->country == "Zambia"): ?> selected <?php endif; ?>>Zambia</option>
                                                    <option value="Zimbabwe" <?php if($data->country == "Zimbabwe"): ?> selected <?php endif; ?>>Zimbabwe</option>
                                                </select>
                                            </div>
                                            
                                            <div class="eight wide field">
                                                <h2 class="ui small header"><?php echo e(__("Time zone")); ?>

                                                    <div class="sub header"><?php echo e(__("Select your region, and city to sync time for attendance")); ?></div>
                                                </h2>
                                                <select name="timezone" class="ui search dropdown uppercase">
                                                    <option value="">Select Timezone</option>
                                                    <option value="Pacific/Midway" <?php if($data->timezone == "Pacific/Midway"): ?> selected <?php endif; ?>>(UTC -11:00) Pacific/Midway</option>
                                                    <option value="Pacific/Niue" <?php if($data->timezone == "Pacific/Niue"): ?> selected <?php endif; ?>>(UTC -11:00) Pacific/Niue</option>
                                                    <option value="Pacific/Pago_Pago" <?php if($data->timezone == "Pacific/Pago_Pago"): ?> selected <?php endif; ?>>(UTC -11:00) Pacific/Pago_Pago</option>
                                                    <option value="America/Adak" <?php if($data->timezone == "America/Adak"): ?> selected <?php endif; ?>>(UTC -10:00) America/Adak</option>
                                                    <option value="Pacific/Honolulu" <?php if($data->timezone == "Pacific/Honolulu"): ?> selected <?php endif; ?>>(UTC -10:00) Pacific/Honolulu</option>
                                                    <option value="Pacific/Rarotonga" <?php if($data->timezone == "Pacific/Rarotonga"): ?> selected <?php endif; ?>>(UTC -10:00) Pacific/Rarotonga</option>
                                                    <option value="Pacific/Tahiti" <?php if($data->timezone == "Pacific/Tahiti"): ?> selected <?php endif; ?>>(UTC -10:00) Pacific/Tahiti</option>
                                                    <option value="Pacific/Marquesas" <?php if($data->timezone == "Pacific/Marquesas"): ?> selected <?php endif; ?>>(UTC -09:30) Pacific/Marquesas</option>
                                                    <option value="America/Anchorage" <?php if($data->timezone == "America/Anchorage"): ?> selected <?php endif; ?>>(UTC -09:00) America/Anchorage</option>
                                                    <option value="America/Juneau" <?php if($data->timezone == "America/Juneau"): ?> selected <?php endif; ?>>(UTC -09:00) America/Juneau</option>
                                                    <option value="America/Metlakatla" <?php if($data->timezone == "America/Metlakatla"): ?> selected <?php endif; ?>>(UTC -09:00) America/Metlakatla</option>
                                                    <option value="America/Nome" <?php if($data->timezone == "America/Nome"): ?> selected <?php endif; ?>>(UTC -09:00) America/Nome</option>
                                                    <option value="America/Sitka" <?php if($data->timezone == "America/Sitka"): ?> selected <?php endif; ?>>(UTC -09:00) America/Sitka</option>
                                                    <option value="America/Yakutat" <?php if($data->timezone == "America/Yakutat"): ?> selected <?php endif; ?>>(UTC -09:00) America/Yakutat</option>
                                                    <option value="Pacific/Gambier" <?php if($data->timezone == "Pacific/Gambier"): ?> selected <?php endif; ?>>(UTC -09:00) Pacific/Gambier</option>
                                                    <option value="America/Dawson" <?php if($data->timezone == "America/Dawson"): ?> selected <?php endif; ?>>(UTC -08:00) America/Dawson</option>
                                                    <option value="America/Los_Angeles" <?php if($data->timezone == "America/Los_Angeles"): ?> selected <?php endif; ?>>(UTC -08:00) America/Los_Angeles</option>
                                                    <option value="America/Tijuana" <?php if($data->timezone == "America/Tijuana"): ?> selected <?php endif; ?>>(UTC -08:00) America/Tijuana</option>
                                                    <option value="America/Vancouver" <?php if($data->timezone == "America/Vancouver"): ?> selected <?php endif; ?>>(UTC -08:00) America/Vancouver</option>
                                                    <option value="America/Whitehorse" <?php if($data->timezone == "America/Whitehorse"): ?> selected <?php endif; ?>>(UTC -08:00) America/Whitehorse</option>
                                                    <option value="Pacific/Pitcairn" <?php if($data->timezone == "Pacific/Pitcairn"): ?> selected <?php endif; ?>>(UTC -08:00) Pacific/Pitcairn</option>
                                                    <option value="America/Boise" <?php if($data->timezone == "America/Boise"): ?> selected <?php endif; ?>>(UTC -07:00) America/Boise</option>
                                                    <option value="America/Cambridge_Bay" <?php if($data->timezone == "America/Cambridge_Bay"): ?> selected <?php endif; ?>>(UTC -07:00) America/Cambridge_Bay</option>
                                                    <option value="America/Chihuahua" <?php if($data->timezone == "America/Chihuahua"): ?> selected <?php endif; ?>>(UTC -07:00) America/Chihuahua</option>
                                                    <option value="America/Creston" <?php if($data->timezone == "America/Creston"): ?> selected <?php endif; ?>>(UTC -07:00) America/Creston</option>
                                                    <option value="America/Dawson_Creek" <?php if($data->timezone == "America/Dawson_Creek"): ?> selected <?php endif; ?>>(UTC -07:00) America/Dawson_Creek</option>
                                                    <option value="America/Denver" <?php if($data->timezone == "America/Denver"): ?> selected <?php endif; ?>>(UTC -07:00) America/Denver</option>
                                                    <option value="America/Edmonton" <?php if($data->timezone == "America/Edmonton"): ?> selected <?php endif; ?>>(UTC -07:00) America/Edmonton</option>
                                                    <option value="America/Fort_Nelson" <?php if($data->timezone == "America/Fort_Nelson"): ?> selected <?php endif; ?>>(UTC -07:00) America/Fort_Nelson</option>
                                                    <option value="America/Hermosillo" <?php if($data->timezone == "America/Hermosillo"): ?> selected <?php endif; ?>>(UTC -07:00) America/Hermosillo</option>
                                                    <option value="America/Inuvik" <?php if($data->timezone == "America/Inuvik"): ?> selected <?php endif; ?>>(UTC -07:00) America/Inuvik</option>
                                                    <option value="America/Mazatlan" <?php if($data->timezone == "America/Mazatlan"): ?> selected <?php endif; ?>>(UTC -07:00) America/Mazatlan</option>
                                                    <option value="America/Ojinaga" <?php if($data->timezone == "America/Ojinaga"): ?> selected <?php endif; ?>>(UTC -07:00) America/Ojinaga</option>
                                                    <option value="America/Phoenix" <?php if($data->timezone == "America/Phoenix"): ?> selected <?php endif; ?>>(UTC -07:00) America/Phoenix</option>
                                                    <option value="America/Yellowknife" <?php if($data->timezone == "America/Yellowknife"): ?> selected <?php endif; ?>>(UTC -07:00) America/Yellowknife</option>
                                                    <option value="America/Bahia_Banderas" <?php if($data->timezone == "America/Bahia_Banderas"): ?> selected <?php endif; ?>>(UTC -06:00) America/Bahia_Banderas</option>
                                                    <option value="America/Belize" <?php if($data->timezone == "America/Belize"): ?> selected <?php endif; ?>>(UTC -06:00) America/Belize</option>
                                                    <option value="America/Chicago" <?php if($data->timezone == "America/Chicago"): ?> selected <?php endif; ?>>(UTC -06:00) America/Chicago</option>
                                                    <option value="America/Costa_Rica" <?php if($data->timezone == "America/Costa_Rica"): ?> selected <?php endif; ?>>(UTC -06:00) America/Costa_Rica</option>
                                                    <option value="America/El_Salvador" <?php if($data->timezone == "America/El_Salvador"): ?> selected <?php endif; ?>>(UTC -06:00) America/El_Salvador</option>
                                                    <option value="America/Guatemala" <?php if($data->timezone == "America/Guatemala"): ?> selected <?php endif; ?>>(UTC -06:00) America/Guatemala</option>
                                                    <option value="America/Indiana/Knox" <?php if($data->timezone == "America/Indiana/Knox"): ?> selected <?php endif; ?>>(UTC -06:00) America/Indiana/Knox</option>
                                                    <option value="America/Indiana/Tell_City" <?php if($data->timezone == "America/Indiana/Tell_City"): ?> selected <?php endif; ?>>(UTC -06:00) America/Indiana/Tell_City</option>
                                                    <option value="America/Managua" <?php if($data->timezone == "America/Managua"): ?> selected <?php endif; ?>>(UTC -06:00) America/Managua</option>
                                                    <option value="America/Matamoros" <?php if($data->timezone == "America/Matamoros"): ?> selected <?php endif; ?>>(UTC -06:00) America/Matamoros</option>
                                                    <option value="America/Menominee" <?php if($data->timezone == "America/Menominee"): ?> selected <?php endif; ?>>(UTC -06:00) America/Menominee</option>
                                                    <option value="America/Merida" <?php if($data->timezone == "America/Merida"): ?> selected <?php endif; ?>>(UTC -06:00) America/Merida</option>
                                                    <option value="America/Mexico_City" <?php if($data->timezone == "America/Mexico_City"): ?> selected <?php endif; ?>>(UTC -06:00) America/Mexico_City</option>
                                                    <option value="America/Monterrey" <?php if($data->timezone == "America/Monterrey"): ?> selected <?php endif; ?>>(UTC -06:00) America/Monterrey</option>
                                                    <option value="America/North_Dakota/Beulah" <?php if($data->timezone == "America/North_Dakota/Beulah"): ?> selected <?php endif; ?>>(UTC -06:00) America/North_Dakota/Beulah</option>
                                                    <option value="America/North_Dakota/Center" <?php if($data->timezone == "America/North_Dakota/Center"): ?> selected <?php endif; ?>>(UTC -06:00) America/North_Dakota/Center</option>
                                                    <option value="America/North_Dakota/New_Salem" <?php if($data->timezone == "America/North_Dakota/New_Salem"): ?> selected <?php endif; ?>>(UTC -06:00) America/North_Dakota/New_Salem</option>
                                                    <option value="America/Rainy_River" <?php if($data->timezone == "America/Rainy_River"): ?> selected <?php endif; ?>>(UTC -06:00) America/Rainy_River</option>
                                                    <option value="America/Rankin_Inlet" <?php if($data->timezone == "America/Rankin_Inlet"): ?> selected <?php endif; ?>>(UTC -06:00) America/Rankin_Inlet</option>
                                                    <option value="America/Regina" <?php if($data->timezone == "America/Regina"): ?> selected <?php endif; ?>>(UTC -06:00) America/Regina</option>
                                                    <option value="America/Resolute" <?php if($data->timezone == "America/Resolute"): ?> selected <?php endif; ?>>(UTC -06:00) America/Resolute</option>
                                                    <option value="America/Swift_Current" <?php if($data->timezone == "America/Swift_Current"): ?> selected <?php endif; ?>>(UTC -06:00) America/Swift_Current</option>
                                                    <option value="America/Tegucigalpa" <?php if($data->timezone == "America/Tegucigalpa"): ?> selected <?php endif; ?>>(UTC -06:00) America/Tegucigalpa</option>
                                                    <option value="America/Winnipeg" <?php if($data->timezone == "America/Winnipeg"): ?> selected <?php endif; ?>>(UTC -06:00) America/Winnipeg</option>
                                                    <option value="Pacific/Galapagos" <?php if($data->timezone == "Pacific/Galapagos"): ?> selected <?php endif; ?>>(UTC -06:00) Pacific/Galapagos</option>
                                                    <option value="America/Atikokan" <?php if($data->timezone == "America/Atikokan"): ?> selected <?php endif; ?>>(UTC -05:00) America/Atikokan</option>
                                                    <option value="America/Bogota" <?php if($data->timezone == "America/Bogota"): ?> selected <?php endif; ?>>(UTC -05:00) America/Bogota</option>
                                                    <option value="America/Cancun" <?php if($data->timezone == "America/Cancun"): ?> selected <?php endif; ?>>(UTC -05:00) America/Cancun</option>
                                                    <option value="America/Cayman" <?php if($data->timezone == "America/Cayman"): ?> selected <?php endif; ?>>(UTC -05:00) America/Cayman</option>
                                                    <option value="America/Detroit" <?php if($data->timezone == "America/Detroit"): ?> selected <?php endif; ?>>(UTC -05:00) America/Detroit</option>
                                                    <option value="America/Eirunepe" <?php if($data->timezone == "America/Eirunepe"): ?> selected <?php endif; ?>>(UTC -05:00) America/Eirunepe</option>
                                                    <option value="America/Guayaquil" <?php if($data->timezone == "America/Guayaquil"): ?> selected <?php endif; ?>>(UTC -05:00) America/Guayaquil</option>
                                                    <option value="America/Havana" <?php if($data->timezone == "America/Havana"): ?> selected <?php endif; ?>>(UTC -05:00) America/Havana</option>
                                                    <option value="America/Indiana/Indianapolis" <?php if($data->timezone == "America/Indiana/Indianapolis"): ?> selected <?php endif; ?>>(UTC -05:00) America/Indiana/Indianapolis</option>
                                                    <option value="America/Indiana/Marengo" <?php if($data->timezone == "America/Indiana/Marengo"): ?> selected <?php endif; ?>>(UTC -05:00) America/Indiana/Marengo</option>
                                                    <option value="America/Indiana/Petersburg" <?php if($data->timezone == "America/Indiana/Petersburg"): ?> selected <?php endif; ?>>(UTC -05:00) America/Indiana/Petersburg</option>
                                                    <option value="America/Indiana/Vevay" <?php if($data->timezone == "America/Indiana/Vevay"): ?> selected <?php endif; ?>>(UTC -05:00) America/Indiana/Vevay</option>
                                                    <option value="America/Indiana/Vincennes" <?php if($data->timezone == "America/Indiana/Vincennes"): ?> selected <?php endif; ?>>(UTC -05:00) America/Indiana/Vincennes</option>
                                                    <option value="America/Indiana/Winamac" <?php if($data->timezone == "America/Indiana/Winamac"): ?> selected <?php endif; ?>>(UTC -05:00) America/Indiana/Winamac</option>
                                                    <option value="America/Iqaluit" <?php if($data->timezone == "America/Iqaluit"): ?> selected <?php endif; ?>>(UTC -05:00) America/Iqaluit</option>
                                                    <option value="America/Jamaica" <?php if($data->timezone == "America/Jamaica"): ?> selected <?php endif; ?>>(UTC -05:00) America/Jamaica</option>
                                                    <option value="America/Kentucky/Louisville" <?php if($data->timezone == "America/Kentucky/Louisville"): ?> selected <?php endif; ?>>(UTC -05:00) America/Kentucky/Louisville</option>
                                                    <option value="America/Kentucky/Monticello" <?php if($data->timezone == "America/Kentucky/Monticello"): ?> selected <?php endif; ?>>(UTC -05:00) America/Kentucky/Monticello</option>
                                                    <option value="America/Lima" <?php if($data->timezone == "America/Lima"): ?> selected <?php endif; ?>>(UTC -05:00) America/Lima</option>
                                                    <option value="America/Nassau" <?php if($data->timezone == "America/Nassau"): ?> selected <?php endif; ?>>(UTC -05:00) America/Nassau</option>
                                                    <option value="America/New_York" <?php if($data->timezone == "America/New_York"): ?> selected <?php endif; ?>>(UTC -05:00) America/New_York</option>
                                                    <option value="America/Nipigon" <?php if($data->timezone == "America/Nipigon"): ?> selected <?php endif; ?>>(UTC -05:00) America/Nipigon</option>
                                                    <option value="America/Panama" <?php if($data->timezone == "America/Panama"): ?> selected <?php endif; ?>>(UTC -05:00) America/Panama</option>
                                                    <option value="America/Pangnirtung" <?php if($data->timezone == "America/Pangnirtung"): ?> selected <?php endif; ?>>(UTC -05:00) America/Pangnirtung</option>
                                                    <option value="America/Port-au-Prince" <?php if($data->timezone == "America/Port-au-Prince"): ?> selected <?php endif; ?>>(UTC -05:00) America/Port-au-Prince</option>
                                                    <option value="America/Rio_Branco" <?php if($data->timezone == "America/Rio_Branco"): ?> selected <?php endif; ?>>(UTC -05:00) America/Rio_Branco</option>
                                                    <option value="America/Thunder_Bay" <?php if($data->timezone == "America/Thunder_Bay"): ?> selected <?php endif; ?>>(UTC -05:00) America/Thunder_Bay</option>
                                                    <option value="America/Toronto" <?php if($data->timezone == "America/Toronto"): ?> selected <?php endif; ?>>(UTC -05:00) America/Toronto</option>
                                                    <option value="Pacific/Easter" <?php if($data->timezone == "Pacific/Easter"): ?> selected <?php endif; ?>>(UTC -05:00) Pacific/Easter</option>
                                                    <option value="America/Anguilla" <?php if($data->timezone == "America/Anguilla"): ?> selected <?php endif; ?>>(UTC -04:00) America/Anguilla</option>
                                                    <option value="America/Antigua" <?php if($data->timezone == "America/Antigua"): ?> selected <?php endif; ?>>(UTC -04:00) America/Antigua</option>
                                                    <option value="America/Aruba" <?php if($data->timezone == "America/Aruba"): ?> selected <?php endif; ?>>(UTC -04:00) America/Aruba</option>
                                                    <option value="America/Barbados" <?php if($data->timezone == "America/Barbados"): ?> selected <?php endif; ?>>(UTC -04:00) America/Barbados</option>
                                                    <option value="America/Blanc-Sablon" <?php if($data->timezone == "America/Blanc-Sablon"): ?> selected <?php endif; ?>>(UTC -04:00) America/Blanc-Sablon</option>
                                                    <option value="America/Boa_Vista" <?php if($data->timezone == "America/Boa_Vista"): ?> selected <?php endif; ?>>(UTC -04:00) America/Boa_Vista</option>
                                                    <option value="America/Caracas" <?php if($data->timezone == "America/Caracas"): ?> selected <?php endif; ?>>(UTC -04:00) America/Caracas</option>
                                                    <option value="America/Curacao" <?php if($data->timezone == "America/Curacao"): ?> selected <?php endif; ?>>(UTC -04:00) America/Curacao</option>
                                                    <option value="America/Dominica" <?php if($data->timezone == "America/Dominica"): ?> selected <?php endif; ?>>(UTC -04:00) America/Dominica</option>
                                                    <option value="America/Glace_Bay" <?php if($data->timezone == "America/Glace_Bay"): ?> selected <?php endif; ?>>(UTC -04:00) America/Glace_Bay</option>
                                                    <option value="America/Goose_Bay" <?php if($data->timezone == "America/Goose_Bay"): ?> selected <?php endif; ?>>(UTC -04:00) America/Goose_Bay</option>
                                                    <option value="America/Grand_Turk" <?php if($data->timezone == "America/Grand_Turk"): ?> selected <?php endif; ?>>(UTC -04:00) America/Grand_Turk</option>
                                                    <option value="America/Grenada" <?php if($data->timezone == "America/Grenada"): ?> selected <?php endif; ?>>(UTC -04:00) America/Grenada</option>
                                                    <option value="America/Guadeloupe" <?php if($data->timezone == "America/Guadeloupe"): ?> selected <?php endif; ?>>(UTC -04:00) America/Guadeloupe</option>
                                                    <option value="America/Guyana" <?php if($data->timezone == "America/Guyana"): ?> selected <?php endif; ?>>(UTC -04:00) America/Guyana</option>
                                                    <option value="America/Halifax" <?php if($data->timezone == "America/Halifax"): ?> selected <?php endif; ?>>(UTC -04:00) America/Halifax</option>
                                                    <option value="America/Kralendijk" <?php if($data->timezone == "America/Kralendijk"): ?> selected <?php endif; ?>>(UTC -04:00) America/Kralendijk</option>
                                                    <option value="America/La_Paz" <?php if($data->timezone == "America/La_Paz"): ?> selected <?php endif; ?>>(UTC -04:00) America/La_Paz</option>
                                                    <option value="America/Lower_Princes" <?php if($data->timezone == "America/Lower_Princes"): ?> selected <?php endif; ?>>(UTC -04:00) America/Lower_Princes</option>
                                                    <option value="America/Manaus" <?php if($data->timezone == "America/Manaus"): ?> selected <?php endif; ?>>(UTC -04:00) America/Manaus</option>
                                                    <option value="America/Marigot" <?php if($data->timezone == "America/Marigot"): ?> selected <?php endif; ?>>(UTC -04:00) America/Marigot</option>
                                                    <option value="America/Martinique" <?php if($data->timezone == "America/Martinique"): ?> selected <?php endif; ?>>(UTC -04:00) America/Martinique</option>
                                                    <option value="America/Moncton" <?php if($data->timezone == "America/Moncton"): ?> selected <?php endif; ?>>(UTC -04:00) America/Moncton</option>
                                                    <option value="America/Montserrat" <?php if($data->timezone == "America/Montserrat"): ?> selected <?php endif; ?>>(UTC -04:00) America/Montserrat</option>
                                                    <option value="America/Port_of_Spain" <?php if($data->timezone == "America/Port_of_Spain"): ?> selected <?php endif; ?>>(UTC -04:00) America/Port_of_Spain</option>
                                                    <option value="America/Porto_Velho" <?php if($data->timezone == "America/Porto_Velho"): ?> selected <?php endif; ?>>(UTC -04:00) America/Porto_Velho</option>
                                                    <option value="America/Puerto_Rico" <?php if($data->timezone == "America/Puerto_Rico"): ?> selected <?php endif; ?>>(UTC -04:00) America/Puerto_Rico</option>
                                                    <option value="America/Santo_Domingo" <?php if($data->timezone == "America/Santo_Domingo"): ?> selected <?php endif; ?>>(UTC -04:00) America/Santo_Domingo</option>
                                                    <option value="America/St_Barthelemy" <?php if($data->timezone == "America/St_Barthelemy"): ?> selected <?php endif; ?>>(UTC -04:00) America/St_Barthelemy</option>
                                                    <option value="America/St_Kitts" <?php if($data->timezone == "America/St_Kitts"): ?> selected <?php endif; ?>>(UTC -04:00) America/St_Kitts</option>
                                                    <option value="America/St_Lucia" <?php if($data->timezone == "America/St_Lucia"): ?> selected <?php endif; ?>>(UTC -04:00) America/St_Lucia</option>
                                                    <option value="America/St_Thomas" <?php if($data->timezone == "America/St_Thomas"): ?> selected <?php endif; ?>>(UTC -04:00) America/St_Thomas</option>
                                                    <option value="America/St_Vincent" <?php if($data->timezone == "America/St_Vincent"): ?> selected <?php endif; ?>>(UTC -04:00) America/St_Vincent</option>
                                                    <option value="America/Thule" <?php if($data->timezone == "America/Thule"): ?> selected <?php endif; ?>>(UTC -04:00) America/Thule</option>
                                                    <option value="America/Tortola" <?php if($data->timezone == "America/Tortola"): ?> selected <?php endif; ?>>(UTC -04:00) America/Tortola</option>
                                                    <option value="Atlantic/Bermuda" <?php if($data->timezone == "Atlantic/Bermuda"): ?> selected <?php endif; ?>>(UTC -04:00) Atlantic/Bermuda</option>
                                                    <option value="America/St_Johns" <?php if($data->timezone == "America/St_Johns"): ?> selected <?php endif; ?>>(UTC -03:30) America/St_Johns</option>
                                                    <option value="America/Araguaina" <?php if($data->timezone == "America/Araguaina"): ?> selected <?php endif; ?>>(UTC -03:00) America/Araguaina</option>
                                                    <option value="America/Argentina/Buenos_Aires" <?php if($data->timezone == "America/Argentina/Buenos_Aires"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Buenos_Aires</option>
                                                    <option value="America/Argentina/Catamarca" <?php if($data->timezone == "America/Argentina/Catamarca"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Catamarca</option>
                                                    <option value="America/Argentina/Cordoba" <?php if($data->timezone == "America/Argentina/Cordoba"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Cordoba</option>
                                                    <option value="America/Argentina/Jujuy" <?php if($data->timezone == "America/Argentina/Jujuy"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Jujuy</option>
                                                    <option value="America/Argentina/La_Rioja" <?php if($data->timezone == "America/Argentina/La_Rioja"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/La_Rioja</option>
                                                    <option value="America/Argentina/Mendoza" <?php if($data->timezone == "America/Argentina/Mendoza"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Mendoza</option>
                                                    <option value="America/Argentina/Rio_Gallegos" <?php if($data->timezone == "America/Argentina/Rio_Gallegos"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Rio_Gallegos</option>
                                                    <option value="America/Argentina/Salta" <?php if($data->timezone == "America/Argentina/Salta"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Salta</option>
                                                    <option value="America/Argentina/San_Juan" <?php if($data->timezone == "America/Argentina/San_Juan"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/San_Juan</option>
                                                    <option value="America/Argentina/San_Luis" <?php if($data->timezone == "America/Argentina/San_Luis"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/San_Luis</option>
                                                    <option value="America/Argentina/Tucuman" <?php if($data->timezone == "America/Argentina/Tucuman"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Tucuman</option>
                                                    <option value="America/Argentina/Ushuaia" <?php if($data->timezone == "America/Argentina/Ushuaia"): ?> selected <?php endif; ?>>(UTC -03:00) America/Argentina/Ushuaia</option>
                                                    <option value="America/Asuncion" <?php if($data->timezone == "America/Asuncion"): ?> selected <?php endif; ?>>(UTC -03:00) America/Asuncion</option>
                                                    <option value="America/Bahia" <?php if($data->timezone == "America/Bahia"): ?> selected <?php endif; ?>>(UTC -03:00) America/Bahia</option>
                                                    <option value="America/Belem" <?php if($data->timezone == "America/Belem"): ?> selected <?php endif; ?>>(UTC -03:00) America/Belem</option>
                                                    <option value="America/Campo_Grande" <?php if($data->timezone == "America/Campo_Grande"): ?> selected <?php endif; ?>>(UTC -03:00) America/Campo_Grande</option>
                                                    <option value="America/Cayenne" <?php if($data->timezone == "America/Cayenne"): ?> selected <?php endif; ?>>(UTC -03:00) America/Cayenne</option>
                                                    <option value="America/Cuiaba" <?php if($data->timezone == "America/Cuiaba"): ?> selected <?php endif; ?>>(UTC -03:00) America/Cuiaba</option>
                                                    <option value="America/Fortaleza" <?php if($data->timezone == "America/Fortaleza"): ?> selected <?php endif; ?>>(UTC -03:00) America/Fortaleza</option>
                                                    <option value="America/Godthab" <?php if($data->timezone == "America/Godthab"): ?> selected <?php endif; ?>>(UTC -03:00) America/Godthab</option>
                                                    <option value="America/Maceio" <?php if($data->timezone == "America/Maceio"): ?> selected <?php endif; ?>>(UTC -03:00) America/Maceio</option>
                                                    <option value="America/Miquelon" <?php if($data->timezone == "America/Miquelon"): ?> selected <?php endif; ?>>(UTC -03:00) America/Miquelon</option>
                                                    <option value="America/Montevideo" <?php if($data->timezone == "America/Montevideo"): ?> selected <?php endif; ?>>(UTC -03:00) America/Montevideo</option>
                                                    <option value="America/Paramaribo" <?php if($data->timezone == "America/Paramaribo"): ?> selected <?php endif; ?>>(UTC -03:00) America/Paramaribo</option>
                                                    <option value="America/Punta_Arenas" <?php if($data->timezone == "America/Punta_Arenas"): ?> selected <?php endif; ?>>(UTC -03:00) America/Punta_Arenas</option>
                                                    <option value="America/Recife" <?php if($data->timezone == "America/Recife"): ?> selected <?php endif; ?>>(UTC -03:00) America/Recife</option>
                                                    <option value="America/Santarem" <?php if($data->timezone == "America/Santarem"): ?> selected <?php endif; ?>>(UTC -03:00) America/Santarem</option>
                                                    <option value="America/Santiago" <?php if($data->timezone == "America/Santiago"): ?> selected <?php endif; ?>>(UTC -03:00) America/Santiago</option>
                                                    <option value="Antarctica/Palmer" <?php if($data->timezone == "Antarctica/Palmer"): ?> selected <?php endif; ?>>(UTC -03:00) Antarctica/Palmer</option>
                                                    <option value="Antarctica/Rothera" <?php if($data->timezone == "Antarctica/Rothera"): ?> selected <?php endif; ?>>(UTC -03:00) Antarctica/Rothera</option>
                                                    <option value="Atlantic/Stanley" <?php if($data->timezone == "Atlantic/Stanley"): ?> selected <?php endif; ?>>(UTC -03:00) Atlantic/Stanley</option>
                                                    <option value="America/Noronha" <?php if($data->timezone == "America/Noronha"): ?> selected <?php endif; ?>>(UTC -02:00) America/Noronha</option>
                                                    <option value="America/Sao_Paulo" <?php if($data->timezone == "America/Sao_Paulo"): ?> selected <?php endif; ?>>(UTC -02:00) America/Sao_Paulo</option>
                                                    <option value="Atlantic/South_Georgia" <?php if($data->timezone == "Atlantic/South_Georgia"): ?> selected <?php endif; ?>>(UTC -02:00) Atlantic/South_Georgia</option>
                                                    <option value="America/Scoresbysund" <?php if($data->timezone == "America/Scoresbysund"): ?> selected <?php endif; ?>>(UTC -01:00) America/Scoresbysund</option>
                                                    <option value="Atlantic/Azores" <?php if($data->timezone == "Atlantic/Azores"): ?> selected <?php endif; ?>>(UTC -01:00) Atlantic/Azores</option>
                                                    <option value="Atlantic/Cape_Verde" <?php if($data->timezone == "Atlantic/Cape_Verde"): ?> selected <?php endif; ?>>(UTC -01:00) Atlantic/Cape_Verde</option>
                                                    <option value="Africa/Abidjan" <?php if($data->timezone == "Africa/Abidjan"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Abidjan</option>
                                                    <option value="Africa/Accra" <?php if($data->timezone == "Africa/Accra"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Accra</option>
                                                    <option value="Africa/Bamako" <?php if($data->timezone == "Africa/Bamako"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Bamako</option>
                                                    <option value="Africa/Banjul" <?php if($data->timezone == "Africa/Banjul"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Banjul</option>
                                                    <option value="Africa/Bissau" <?php if($data->timezone == "Africa/Bissau"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Bissau</option>
                                                    <option value="Africa/Casablanca" <?php if($data->timezone == "Africa/Casablanca"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Casablanca</option>
                                                    <option value="Africa/Conakry" <?php if($data->timezone == "Africa/Conakry"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Conakry</option>
                                                    <option value="Africa/Dakar" <?php if($data->timezone == "Africa/Dakar"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Dakar</option>
                                                    <option value="Africa/El_Aaiun" <?php if($data->timezone == "Africa/El_Aaiun"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/El_Aaiun</option>
                                                    <option value="Africa/Freetown" <?php if($data->timezone == "Africa/Freetown"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Freetown</option>
                                                    <option value="Africa/Lome" <?php if($data->timezone == "Africa/Lome"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Lome</option>
                                                    <option value="Africa/Monrovia" <?php if($data->timezone == "Africa/Monrovia"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Monrovia</option>
                                                    <option value="Africa/Nouakchott" <?php if($data->timezone == "Africa/Nouakchott"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Nouakchott</option>
                                                    <option value="Africa/Ouagadougou" <?php if($data->timezone == "Africa/Ouagadougou"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Ouagadougou</option>
                                                    <option value="Africa/Sao_Tome" <?php if($data->timezone == "Africa/Sao_Tome"): ?> selected <?php endif; ?>>(UTC -00:00) Africa/Sao_Tome</option>
                                                    <option value="America/Danmarkshavn" <?php if($data->timezone == "America/Danmarkshavn"): ?> selected <?php endif; ?>>(UTC -00:00) America/Danmarkshavn</option>
                                                    <option value="Antarctica/Troll" <?php if($data->timezone == "Antarctica/Troll"): ?> selected <?php endif; ?>>(UTC -00:00) Antarctica/Troll</option>
                                                    <option value="Atlantic/Canary" <?php if($data->timezone == "Atlantic/Canary"): ?> selected <?php endif; ?>>(UTC -00:00) Atlantic/Canary</option>
                                                    <option value="Atlantic/Faroe" <?php if($data->timezone == "Atlantic/Faroe"): ?> selected <?php endif; ?>>(UTC -00:00) Atlantic/Faroe</option>
                                                    <option value="Atlantic/Madeira" <?php if($data->timezone == "Atlantic/Madeira"): ?> selected <?php endif; ?>>(UTC -00:00) Atlantic/Madeira</option>
                                                    <option value="Atlantic/Reykjavik" <?php if($data->timezone == "Atlantic/Reykjavik"): ?> selected <?php endif; ?>>(UTC -00:00) Atlantic/Reykjavik</option>
                                                    <option value="Atlantic/St_Helena" <?php if($data->timezone == "Atlantic/St_Helena"): ?> selected <?php endif; ?>>(UTC -00:00) Atlantic/St_Helena</option>
                                                    <option value="Europe/Dublin" <?php if($data->timezone == "Europe/Dublin"): ?> selected <?php endif; ?>>(UTC -00:00) Europe/Dublin</option>
                                                    <option value="Europe/Guernsey" <?php if($data->timezone == "Europe/Guernsey"): ?> selected <?php endif; ?>>(UTC -00:00) Europe/Guernsey</option>
                                                    <option value="Europe/Isle_of_Man" <?php if($data->timezone == "Europe/Isle_of_Man"): ?> selected <?php endif; ?>>(UTC -00:00) Europe/Isle_of_Man</option>
                                                    <option value="Europe/Jersey" <?php if($data->timezone == "Europe/Jersey"): ?> selected <?php endif; ?>>(UTC -00:00) Europe/Jersey</option>
                                                    <option value="Europe/Lisbon" <?php if($data->timezone == "Europe/Lisbon"): ?> selected <?php endif; ?>>(UTC -00:00) Europe/Lisbon</option>
                                                    <option value="Europe/London" <?php if($data->timezone == "Europe/London"): ?> selected <?php endif; ?>>(UTC -00:00) Europe/London</option>
                                                    <option value="UTC" <?php if($data->timezone == "UTC"): ?> selected <?php endif; ?>>(UTC -00:00) UTC</option>
                                                    <option value="Africa/Algiers" <?php if($data->timezone == "Africa/Algiers"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Algiers</option>
                                                    <option value="Africa/Bangui" <?php if($data->timezone == "Africa/Bangui"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Bangui</option>
                                                    <option value="Africa/Brazzaville" <?php if($data->timezone == "Africa/Brazzaville"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Brazzaville</option>
                                                    <option value="Africa/Ceuta" <?php if($data->timezone == "Africa/Ceuta"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Ceuta</option>
                                                    <option value="Africa/Douala" <?php if($data->timezone == "Africa/Douala"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Douala</option>
                                                    <option value="Africa/Kinshasa" <?php if($data->timezone == "Africa/Kinshasa"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Kinshasa</option>
                                                    <option value="Africa/Lagos" <?php if($data->timezone == "Africa/Lagos"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Lagos</option>
                                                    <option value="Africa/Libreville" <?php if($data->timezone == "Africa/Libreville"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Libreville</option>
                                                    <option value="Africa/Luanda" <?php if($data->timezone == "Africa/Luanda"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Luanda</option>
                                                    <option value="Africa/Malabo" <?php if($data->timezone == "Africa/Malabo"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Malabo</option>
                                                    <option value="Africa/Ndjamena" <?php if($data->timezone == "Africa/Ndjamena"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Ndjamena</option>
                                                    <option value="Africa/Niamey" <?php if($data->timezone == "Africa/Niamey"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Niamey</option>
                                                    <option value="Africa/Porto-Novo" <?php if($data->timezone == "Africa/Porto-Novo"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Porto-Novo</option>
                                                    <option value="Africa/Tunis" <?php if($data->timezone == "Africa/Tunis"): ?> selected <?php endif; ?>>(UTC +01:00) Africa/Tunis</option>
                                                    <option value="Arctic/Longyearbyen" <?php if($data->timezone == "Arctic/Longyearbyen"): ?> selected <?php endif; ?>>(UTC +01:00) Arctic/Longyearbyen</option>
                                                    <option value="Europe/Amsterdam" <?php if($data->timezone == "Europe/Amsterdam"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Amsterdam</option>
                                                    <option value="Europe/Andorra" <?php if($data->timezone == "Europe/Andorra"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Andorra</option>
                                                    <option value="Europe/Belgrade" <?php if($data->timezone == "Europe/Belgrade"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Belgrade</option>
                                                    <option value="Europe/Berlin" <?php if($data->timezone == "Europe/Berlin"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Berlin</option>
                                                    <option value="Europe/Bratislava" <?php if($data->timezone == "Europe/Bratislava"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Bratislava</option>
                                                    <option value="Europe/Brussels" <?php if($data->timezone == "Europe/Brussels"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Brussels</option>
                                                    <option value="Europe/Budapest" <?php if($data->timezone == "Europe/Budapest"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Budapest</option>
                                                    <option value="Europe/Busingen" <?php if($data->timezone == "Europe/Busingen"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Busingen</option>
                                                    <option value="Europe/Copenhagen" <?php if($data->timezone == "Europe/Copenhagen"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Copenhagen</option>
                                                    <option value="Europe/Gibraltar" <?php if($data->timezone == "Europe/Gibraltar"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Gibraltar</option>
                                                    <option value="Europe/Ljubljana" <?php if($data->timezone == "Europe/Ljubljana"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Ljubljana</option>
                                                    <option value="Europe/Luxembourg" <?php if($data->timezone == "Europe/Luxembourg"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Luxembourg</option>
                                                    <option value="Europe/Madrid" <?php if($data->timezone == "Europe/Madrid"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Madrid</option>
                                                    <option value="Europe/Malta" <?php if($data->timezone == "Europe/Malta"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Malta</option>
                                                    <option value="Europe/Monaco" <?php if($data->timezone == "Europe/Monaco"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Monaco</option>
                                                    <option value="Europe/Oslo" <?php if($data->timezone == "Europe/Oslo"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Oslo</option>
                                                    <option value="Europe/Paris" <?php if($data->timezone == "Europe/Paris"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Paris</option>
                                                    <option value="Europe/Podgorica" <?php if($data->timezone == "Europe/Podgorica"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Podgorica</option>
                                                    <option value="Europe/Prague" <?php if($data->timezone == "Europe/Prague"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Prague</option>
                                                    <option value="Europe/Rome" <?php if($data->timezone == "Europe/Rome"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Rome</option>
                                                    <option value="Europe/San_Marino" <?php if($data->timezone == "Europe/San_Marino"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/San_Marino</option>
                                                    <option value="Europe/Sarajevo" <?php if($data->timezone == "Europe/Sarajevo"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Sarajevo</option>
                                                    <option value="Europe/Skopje" <?php if($data->timezone == "Europe/Skopje"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Skopje</option>
                                                    <option value="Europe/Stockholm" <?php if($data->timezone == "Europe/Stockholm"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Stockholm</option>
                                                    <option value="Europe/Tirane" <?php if($data->timezone == "Europe/Tirane"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Tirane</option>
                                                    <option value="Europe/Vaduz" <?php if($data->timezone == "Europe/Vaduz"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Vaduz</option>
                                                    <option value="Europe/Vatican" <?php if($data->timezone == "Europe/Vatican"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Vatican</option>
                                                    <option value="Europe/Vienna" <?php if($data->timezone == "Europe/Vienna"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Vienna</option>
                                                    <option value="Europe/Warsaw" <?php if($data->timezone == "Europe/Warsaw"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Warsaw</option>
                                                    <option value="Europe/Zagreb" <?php if($data->timezone == "Europe/Zagreb"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Zagreb</option>
                                                    <option value="Europe/Zurich" <?php if($data->timezone == "Europe/Zurich"): ?> selected <?php endif; ?>>(UTC +01:00) Europe/Zurich</option>
                                                    <option value="Africa/Blantyre" <?php if($data->timezone == "Africa/Blantyre"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Blantyre</option>
                                                    <option value="Africa/Bujumbura" <?php if($data->timezone == "Africa/Bujumbura"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Bujumbura</option>
                                                    <option value="Africa/Cairo" <?php if($data->timezone == "Africa/Cairo"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Cairo</option>
                                                    <option value="Africa/Gaborone" <?php if($data->timezone == "Africa/Gaborone"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Gaborone</option>
                                                    <option value="Africa/Harare" <?php if($data->timezone == "Africa/Harare"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Harare</option>
                                                    <option value="Africa/Johannesburg" <?php if($data->timezone == "Africa/Johannesburg"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Johannesburg</option>
                                                    <option value="Africa/Kigali" <?php if($data->timezone == "Africa/Kigali"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Kigali</option>
                                                    <option value="Africa/Lubumbashi" <?php if($data->timezone == "Africa/Lubumbashi"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Lubumbashi</option>
                                                    <option value="Africa/Lusaka" <?php if($data->timezone == "Africa/Lusaka"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Lusaka</option>
                                                    <option value="Africa/Maputo" <?php if($data->timezone == "Africa/Maputo"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Maputo</option>
                                                    <option value="Africa/Maseru" <?php if($data->timezone == "Africa/Maseru"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Maseru</option>
                                                    <option value="Africa/Mbabane" <?php if($data->timezone == "Africa/Mbabane"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Mbabane</option>
                                                    <option value="Africa/Tripoli" <?php if($data->timezone == "Africa/Tripoli"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Tripoli</option>
                                                    <option value="Africa/Windhoek" <?php if($data->timezone == "Africa/Windhoek"): ?> selected <?php endif; ?>>(UTC +02:00) Africa/Windhoek</option>
                                                    <option value="Asia/Amman" <?php if($data->timezone == "Asia/Amman"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Amman</option>
                                                    <option value="Asia/Beirut" <?php if($data->timezone == "Asia/Beirut"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Beirut</option>
                                                    <option value="Asia/Damascus" <?php if($data->timezone == "Asia/Damascus"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Damascus</option>
                                                    <option value="Asia/Gaza" <?php if($data->timezone == "Asia/Gaza"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Gaza</option>
                                                    <option value="Asia/Hebron" <?php if($data->timezone == "Asia/Hebron"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Hebron</option>
                                                    <option value="Asia/Jerusalem" <?php if($data->timezone == "Asia/Jerusalem"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Jerusalem</option>
                                                    <option value="Asia/Nicosia" <?php if($data->timezone == "Asia/Nicosia"): ?> selected <?php endif; ?>>(UTC +02:00) Asia/Nicosia</option>
                                                    <option value="Europe/Athens" <?php if($data->timezone == "Europe/Athens"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Athens</option>
                                                    <option value="Europe/Bucharest" <?php if($data->timezone == "Europe/Bucharest"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Bucharest</option>
                                                    <option value="Europe/Chisinau" <?php if($data->timezone == "Europe/Chisinau"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Chisinau</option>
                                                    <option value="Europe/Helsinki" <?php if($data->timezone == "Europe/Helsinki"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Helsinki</option>
                                                    <option value="Europe/Kaliningrad" <?php if($data->timezone == "Europe/Kaliningrad"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Kaliningrad</option>
                                                    <option value="Europe/Kiev" <?php if($data->timezone == "Europe/Kiev"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Kiev</option>
                                                    <option value="Europe/Mariehamn" <?php if($data->timezone == "Europe/Mariehamn"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Mariehamn</option>
                                                    <option value="Europe/Riga" <?php if($data->timezone == "Europe/Riga"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Riga</option>
                                                    <option value="Europe/Sofia" <?php if($data->timezone == "Europe/Sofia"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Sofia</option>
                                                    <option value="Europe/Tallinn" <?php if($data->timezone == "Europe/Tallinn"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Tallinn</option>
                                                    <option value="Europe/Uzhgorod" <?php if($data->timezone == "Europe/Uzhgorod"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Uzhgorod</option>
                                                    <option value="Europe/Vilnius" <?php if($data->timezone == "Europe/Vilnius"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Vilnius</option>
                                                    <option value="Europe/Zaporozhye" <?php if($data->timezone == "Europe/Zaporozhye"): ?> selected <?php endif; ?>>(UTC +02:00) Europe/Zaporozhye</option>
                                                    <option value="Africa/Addis_Ababa" <?php if($data->timezone == "Africa/Addis_Ababa"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Addis_Ababa</option>
                                                    <option value="Africa/Asmara" <?php if($data->timezone == "Africa/Asmara"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Asmara</option>
                                                    <option value="Africa/Dar_es_Salaam" <?php if($data->timezone == "Africa/Dar_es_Salaam"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Dar_es_Salaam</option>
                                                    <option value="Africa/Djibouti" <?php if($data->timezone == "Africa/Djibouti"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Djibouti</option>
                                                    <option value="Africa/Juba" <?php if($data->timezone == "Africa/Juba"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Juba</option>
                                                    <option value="Africa/Kampala" <?php if($data->timezone == "Africa/Kampala"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Kampala</option>
                                                    <option value="Africa/Khartoum" <?php if($data->timezone == "Africa/Khartoum"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Khartoum</option>
                                                    <option value="Africa/Mogadishu" <?php if($data->timezone == "Africa/Mogadishu"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Mogadishu</option>
                                                    <option value="Africa/Nairobi" <?php if($data->timezone == "Africa/Nairobi"): ?> selected <?php endif; ?>>(UTC +03:00) Africa/Nairobi</option>
                                                    <option value="Antarctica/Syowa" <?php if($data->timezone == "Antarctica/Syowa"): ?> selected <?php endif; ?>>(UTC +03:00) Antarctica/Syowa</option>
                                                    <option value="Asia/Aden" <?php if($data->timezone == "Asia/Aden"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Aden</option>
                                                    <option value="Asia/Baghdad" <?php if($data->timezone == "Asia/Baghdad"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Baghdad</option>
                                                    <option value="Asia/Bahrain" <?php if($data->timezone == "Asia/Bahrain"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Bahrain</option>
                                                    <option value="Asia/Famagusta" <?php if($data->timezone == "Asia/Famagusta"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Famagusta</option>
                                                    <option value="Asia/Kuwait" <?php if($data->timezone == "Asia/Kuwait"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Kuwait</option>
                                                    <option value="Asia/Qatar" <?php if($data->timezone == "Asia/Qatar"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Qatar</option>
                                                    <option value="Asia/Riyadh" <?php if($data->timezone == "Asia/Riyadh"): ?> selected <?php endif; ?>>(UTC +03:00) Asia/Riyadh</option>
                                                    <option value="Europe/Istanbul" <?php if($data->timezone == "Europe/Istanbul"): ?> selected <?php endif; ?>>(UTC +03:00) Europe/Istanbul</option>
                                                    <option value="Europe/Kirov" <?php if($data->timezone == "Europe/Kirov"): ?> selected <?php endif; ?>>(UTC +03:00) Europe/Kirov</option>
                                                    <option value="Europe/Minsk" <?php if($data->timezone == "Europe/Minsk"): ?> selected <?php endif; ?>>(UTC +03:00) Europe/Minsk</option>
                                                    <option value="Europe/Moscow" <?php if($data->timezone == "Europe/Moscow"): ?> selected <?php endif; ?>>(UTC +03:00) Europe/Moscow</option>
                                                    <option value="Europe/Simferopol" <?php if($data->timezone == "Europe/Simferopol"): ?> selected <?php endif; ?>>(UTC +03:00) Europe/Simferopol</option>
                                                    <option value="Europe/Volgograd" <?php if($data->timezone == "Europe/Volgograd"): ?> selected <?php endif; ?>>(UTC +03:00) Europe/Volgograd</option>
                                                    <option value="Indian/Antananarivo" <?php if($data->timezone == "Indian/Antananarivo"): ?> selected <?php endif; ?>>(UTC +03:00) Indian/Antananarivo</option>
                                                    <option value="Indian/Comoro" <?php if($data->timezone == "Indian/Comoro"): ?> selected <?php endif; ?>>(UTC +03:00) Indian/Comoro</option>
                                                    <option value="Indian/Mayotte" <?php if($data->timezone == "Indian/Mayotte"): ?> selected <?php endif; ?>>(UTC +03:00) Indian/Mayotte</option>
                                                    <option value="Asia/Tehran" <?php if($data->timezone == "Asia/Tehran"): ?> selected <?php endif; ?>>(UTC +03:30) Asia/Tehran</option>
                                                    <option value="Asia/Baku" <?php if($data->timezone == "Asia/Baku"): ?> selected <?php endif; ?>>(UTC +04:00) Asia/Baku</option>
                                                    <option value="Asia/Dubai" <?php if($data->timezone == "Asia/Dubai"): ?> selected <?php endif; ?>>(UTC +04:00) Asia/Dubai</option>
                                                    <option value="Asia/Muscat" <?php if($data->timezone == "Asia/Muscat"): ?> selected <?php endif; ?>>(UTC +04:00) Asia/Muscat</option>
                                                    <option value="Asia/Tbilisi" <?php if($data->timezone == "Asia/Tbilisi"): ?> selected <?php endif; ?>>(UTC +04:00) Asia/Tbilisi</option>
                                                    <option value="Asia/Yerevan" <?php if($data->timezone == "Asia/Yerevan"): ?> selected <?php endif; ?>>(UTC +04:00) Asia/Yerevan</option>
                                                    <option value="Europe/Astrakhan" <?php if($data->timezone == "Europe/Astrakhan"): ?> selected <?php endif; ?>>(UTC +04:00) Europe/Astrakhan</option>
                                                    <option value="Europe/Samara" <?php if($data->timezone == "Europe/Samara"): ?> selected <?php endif; ?>>(UTC +04:00) Europe/Samara</option>
                                                    <option value="Europe/Saratov" <?php if($data->timezone == "Europe/Saratov"): ?> selected <?php endif; ?>>(UTC +04:00) Europe/Saratov</option>
                                                    <option value="Europe/Ulyanovsk" <?php if($data->timezone == "Europe/Ulyanovsk"): ?> selected <?php endif; ?>>(UTC +04:00) Europe/Ulyanovsk</option>
                                                    <option value="Indian/Mahe" <?php if($data->timezone == "Indian/Mahe"): ?> selected <?php endif; ?>>(UTC +04:00) Indian/Mahe</option>
                                                    <option value="Indian/Mauritius" <?php if($data->timezone == "Indian/Mauritius"): ?> selected <?php endif; ?>>(UTC +04:00) Indian/Mauritius</option>
                                                    <option value="Indian/Reunion" <?php if($data->timezone == "Indian/Reunion"): ?> selected <?php endif; ?>>(UTC +04:00) Indian/Reunion</option>
                                                    <option value="Asia/Kabul" <?php if($data->timezone == "Asia/Kabul"): ?> selected <?php endif; ?>>(UTC +04:30) Asia/Kabul</option>
                                                    <option value="Antarctica/Mawson" <?php if($data->timezone == "Antarctica/Mawson"): ?> selected <?php endif; ?>>(UTC +05:00) Antarctica/Mawson</option>
                                                    <option value="Asia/Aqtau" <?php if($data->timezone == "Asia/Aqtau"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Aqtau</option>
                                                    <option value="Asia/Aqtobe" <?php if($data->timezone == "Asia/Aqtobe"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Aqtobe</option>
                                                    <option value="Asia/Ashgabat" <?php if($data->timezone == "Asia/Ashgabat"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Ashgabat</option>
                                                    <option value="Asia/Atyrau" <?php if($data->timezone == "Asia/Atyrau"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Atyrau</option>
                                                    <option value="Asia/Dushanbe" <?php if($data->timezone == "Asia/Dushanbe"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Dushanbe</option>
                                                    <option value="Asia/Karachi" <?php if($data->timezone == "Asia/Karachi"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Karachi</option>
                                                    <option value="Asia/Oral" <?php if($data->timezone == "Asia/Oral"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Oral</option>
                                                    <option value="Asia/Samarkand" <?php if($data->timezone == "Asia/Samarkand"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Samarkand</option>
                                                    <option value="Asia/Tashkent" <?php if($data->timezone == "Asia/Tashkent"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Tashkent</option>
                                                    <option value="Asia/Yekaterinburg" <?php if($data->timezone == "Asia/Yekaterinburg"): ?> selected <?php endif; ?>>(UTC +05:00) Asia/Yekaterinburg</option>
                                                    <option value="Indian/Kerguelen" <?php if($data->timezone == "Indian/Kerguelen"): ?> selected <?php endif; ?>>(UTC +05:00) Indian/Kerguelen</option>
                                                    <option value="Indian/Maldives" <?php if($data->timezone == "Indian/Maldives"): ?> selected <?php endif; ?>>(UTC +05:00) Indian/Maldives</option>
                                                    <option value="Asia/Colombo" <?php if($data->timezone == "Asia/Colombo"): ?> selected <?php endif; ?>>(UTC +05:30) Asia/Colombo</option>
                                                    <option value="Asia/Kolkata" <?php if($data->timezone == "Asia/Kolkata"): ?> selected <?php endif; ?>>(UTC +05:30) Asia/Kolkata</option>
                                                    <option value="Asia/Kathmandu" <?php if($data->timezone == "Asia/Kathmandu"): ?> selected <?php endif; ?>>(UTC +05:45) Asia/Kathmandu</option>
                                                    <option value="Antarctica/Vostok" <?php if($data->timezone == "Antarctica/Vostok"): ?> selected <?php endif; ?>>(UTC +06:00) Antarctica/Vostok</option>
                                                    <option value="Asia/Almaty" <?php if($data->timezone == "Asia/Almaty"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Almaty</option>
                                                    <option value="Asia/Bishkek" <?php if($data->timezone == "Asia/Bishkek"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Bishkek</option>
                                                    <option value="Asia/Dhaka" <?php if($data->timezone == "Asia/Dhaka"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Dhaka</option>
                                                    <option value="Asia/Omsk" <?php if($data->timezone == "Asia/Omsk"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Omsk</option>
                                                    <option value="Asia/Qyzylorda" <?php if($data->timezone == "Asia/Qyzylorda"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Qyzylorda</option>
                                                    <option value="Asia/Thimphu" <?php if($data->timezone == "Asia/Thimphu"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Thimphu</option>
                                                    <option value="Asia/Urumqi" <?php if($data->timezone == "Asia/Urumqi"): ?> selected <?php endif; ?>>(UTC +06:00) Asia/Urumqi</option>
                                                    <option value="Indian/Chagos" <?php if($data->timezone == "Indian/Chagos"): ?> selected <?php endif; ?>>(UTC +06:00) Indian/Chagos</option>
                                                    <option value="Asia/Yangon" <?php if($data->timezone == "Asia/Yangon"): ?> selected <?php endif; ?>>(UTC +06:30) Asia/Yangon</option>
                                                    <option value="Indian/Cocos" <?php if($data->timezone == "Indian/Cocos"): ?> selected <?php endif; ?>>(UTC +06:30) Indian/Cocos</option>
                                                    <option value="Antarctica/Davis" <?php if($data->timezone == "Antarctica/Davis"): ?> selected <?php endif; ?>>(UTC +07:00) Antarctica/Davis</option>
                                                    <option value="Asia/Bangkok" <?php if($data->timezone == "Asia/Bangkok"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Bangkok</option>
                                                    <option value="Asia/Barnaul" <?php if($data->timezone == "Asia/Barnaul"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Barnaul</option>
                                                    <option value="Asia/Ho_Chi_Minh" <?php if($data->timezone == "Asia/Ho_Chi_Minh"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Ho_Chi_Minh</option>
                                                    <option value="Asia/Hovd" <?php if($data->timezone == "Asia/Hovd"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Hovd</option>
                                                    <option value="Asia/Jakarta" <?php if($data->timezone == "Asia/Jakarta"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Jakarta</option>
                                                    <option value="Asia/Krasnoyarsk" <?php if($data->timezone == "Asia/Krasnoyarsk"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Krasnoyarsk</option>
                                                    <option value="Asia/Novokuznetsk" <?php if($data->timezone == "Asia/Novokuznetsk"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Novokuznetsk</option>
                                                    <option value="Asia/Novosibirsk" <?php if($data->timezone == "Asia/Novosibirsk"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Novosibirsk</option>
                                                    <option value="Asia/Phnom_Penh" <?php if($data->timezone == "Asia/Phnom_Penh"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Phnom_Penh</option>
                                                    <option value="Asia/Pontianak" <?php if($data->timezone == "Asia/Pontianak"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Pontianak</option>
                                                    <option value="Asia/Tomsk" <?php if($data->timezone == "Asia/Tomsk"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Tomsk</option>
                                                    <option value="Asia/Vientiane" <?php if($data->timezone == "Asia/Vientiane"): ?> selected <?php endif; ?>>(UTC +07:00) Asia/Vientiane</option>
                                                    <option value="Indian/Christmas" <?php if($data->timezone == "Indian/Christmas"): ?> selected <?php endif; ?>>(UTC +07:00) Indian/Christmas</option>
                                                    <option value="Asia/Brunei" <?php if($data->timezone == "Asia/Brunei"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Brunei</option>
                                                    <option value="Asia/Choibalsan" <?php if($data->timezone == "Asia/Choibalsan"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Choibalsan</option>
                                                    <option value="Asia/Hong_Kong" <?php if($data->timezone == "Asia/Hong_Kong"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Hong_Kong</option>
                                                    <option value="Asia/Irkutsk" <?php if($data->timezone == "Asia/Irkutsk"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Irkutsk</option>
                                                    <option value="Asia/Kuala_Lumpur" <?php if($data->timezone == "Asia/Kuala_Lumpur"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Kuala_Lumpur</option>
                                                    <option value="Asia/Kuching" <?php if($data->timezone == "Asia/Kuching"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Kuching</option>
                                                    <option value="Asia/Macau" <?php if($data->timezone == "Asia/Macau"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Macau</option>
                                                    <option value="Asia/Makassar" <?php if($data->timezone == "Asia/Makassar"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Makassar</option>
                                                    <option value="Asia/Manila" <?php if($data->timezone == "Asia/Manila"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Manila</option>
                                                    <option value="Asia/Shanghai" <?php if($data->timezone == "Asia/Shanghai"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Shanghai</option>
                                                    <option value="Asia/Singapore" <?php if($data->timezone == "Asia/Singapore"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Singapore</option>
                                                    <option value="Asia/Taipei" <?php if($data->timezone == "Asia/Taipei"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Taipei</option>
                                                    <option value="Asia/Ulaanbaatar" <?php if($data->timezone == "Asia/Ulaanbaatar"): ?> selected <?php endif; ?>>(UTC +08:00) Asia/Ulaanbaatar</option>
                                                    <option value="Australia/Perth" <?php if($data->timezone == "Australia/Perth"): ?> selected <?php endif; ?>>(UTC +08:00) Australia/Perth</option>
                                                    <option value="Asia/Pyongyang" <?php if($data->timezone == "Asia/Pyongyang"): ?> selected <?php endif; ?>>(UTC +08:30) Asia/Pyongyang</option>
                                                    <option value="Australia/Eucla" <?php if($data->timezone == "Australia/Eucla"): ?> selected <?php endif; ?>>(UTC +08:45) Australia/Eucla</option>
                                                    <option value="Asia/Chita" <?php if($data->timezone == "Asia/Chita"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Chita</option>
                                                    <option value="Asia/Dili" <?php if($data->timezone == "Asia/Dili"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Dili</option>
                                                    <option value="Asia/Jayapura" <?php if($data->timezone == "Asia/Jayapura"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Jayapura</option>
                                                    <option value="Asia/Khandyga" <?php if($data->timezone == "Asia/Khandyga"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Khandyga</option>
                                                    <option value="Asia/Seoul" <?php if($data->timezone == "Asia/Seoul"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Seoul</option>
                                                    <option value="Asia/Tokyo" <?php if($data->timezone == "Asia/Tokyo"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Tokyo</option>
                                                    <option value="Asia/Yakutsk" <?php if($data->timezone == "Asia/Yakutsk"): ?> selected <?php endif; ?>>(UTC +09:00) Asia/Yakutsk</option>
                                                    <option value="Pacific/Palau" <?php if($data->timezone == "Pacific/Palau"): ?> selected <?php endif; ?>>(UTC +09:00) Pacific/Palau</option>
                                                    <option value="Australia/Darwin" <?php if($data->timezone == "Australia/Darwin"): ?> selected <?php endif; ?>>(UTC +09:30) Australia/Darwin</option>
                                                    <option value="Antarctica/DumontDUrville" <?php if($data->timezone == "Antarctica/DumontDUrville"): ?> selected <?php endif; ?>>(UTC +10:00) Antarctica/DumontDUrville</option>
                                                    <option value="Asia/Ust-Nera" <?php if($data->timezone == "Asia/Ust-Nera"): ?> selected <?php endif; ?>>(UTC +10:00) Asia/Ust-Nera</option>
                                                    <option value="Asia/Vladivostok" <?php if($data->timezone == "Asia/Vladivostok"): ?> selected <?php endif; ?>>(UTC +10:00) Asia/Vladivostok</option>
                                                    <option value="Australia/Brisbane" <?php if($data->timezone == "Australia/Brisbane"): ?> selected <?php endif; ?>>(UTC +10:00) Australia/Brisbane</option>
                                                    <option value="Australia/Lindeman" <?php if($data->timezone == "Australia/Lindeman"): ?> selected <?php endif; ?>>(UTC +10:00) Australia/Lindeman</option>
                                                    <option value="Pacific/Chuuk" <?php if($data->timezone == "Pacific/Chuuk"): ?> selected <?php endif; ?>>(UTC +10:00) Pacific/Chuuk</option>
                                                    <option value="Pacific/Guam" <?php if($data->timezone == "Pacific/Guam"): ?> selected <?php endif; ?>>(UTC +10:00) Pacific/Guam</option>
                                                    <option value="Pacific/Port_Moresby" <?php if($data->timezone == "Pacific/Port_Moresby"): ?> selected <?php endif; ?>>(UTC +10:00) Pacific/Port_Moresby</option>
                                                    <option value="Pacific/Saipan" <?php if($data->timezone == "Pacific/Saipan"): ?> selected <?php endif; ?>>(UTC +10:00) Pacific/Saipan</option>
                                                    <option value="Australia/Adelaide" <?php if($data->timezone == "Australia/Adelaide"): ?> selected <?php endif; ?>>(UTC +10:30) Australia/Adelaide</option>
                                                    <option value="Australia/Broken_Hill" <?php if($data->timezone == "Australia/Broken_Hill"): ?> selected <?php endif; ?>>(UTC +10:30) Australia/Broken_Hill</option>
                                                    <option value="Antarctica/Casey" <?php if($data->timezone == "Antarctica/Casey"): ?> selected <?php endif; ?>>(UTC +11:00) Antarctica/Casey</option>
                                                    <option value="Antarctica/Macquarie" <?php if($data->timezone == "Antarctica/Macquarie"): ?> selected <?php endif; ?>>(UTC +11:00) Antarctica/Macquarie</option>
                                                    <option value="Asia/Magadan" <?php if($data->timezone == "Asia/Magadan"): ?> selected <?php endif; ?>>(UTC +11:00) Asia/Magadan</option>
                                                    <option value="Asia/Sakhalin" <?php if($data->timezone == "Asia/Sakhalin"): ?> selected <?php endif; ?>>(UTC +11:00) Asia/Sakhalin</option>
                                                    <option value="Asia/Srednekolymsk" <?php if($data->timezone == "Asia/Srednekolymsk"): ?> selected <?php endif; ?>>(UTC +11:00) Asia/Srednekolymsk</option>
                                                    <option value="Australia/Currie" <?php if($data->timezone == "Australia/Currie"): ?> selected <?php endif; ?>>(UTC +11:00) Australia/Currie</option>
                                                    <option value="Australia/Hobart" <?php if($data->timezone == "Australia/Hobart"): ?> selected <?php endif; ?>>(UTC +11:00) Australia/Hobart</option>
                                                    <option value="Australia/Lord_Howe" <?php if($data->timezone == "Australia/Lord_Howe"): ?> selected <?php endif; ?>>(UTC +11:00) Australia/Lord_Howe</option>
                                                    <option value="Australia/Melbourne" <?php if($data->timezone == "Australia/Melbourne"): ?> selected <?php endif; ?>>(UTC +11:00) Australia/Melbourne</option>
                                                    <option value="Australia/Sydney" <?php if($data->timezone == "Australia/Sydney"): ?> selected <?php endif; ?>>(UTC +11:00) Australia/Sydney</option>
                                                    <option value="Pacific/Bougainville" <?php if($data->timezone == "Pacific/Bougainville"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Bougainville</option>
                                                    <option value="Pacific/Efate" <?php if($data->timezone == "Pacific/Efate"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Efate</option>
                                                    <option value="Pacific/Guadalcanal" <?php if($data->timezone == "Pacific/Guadalcanal"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Guadalcanal</option>
                                                    <option value="Pacific/Kosrae" <?php if($data->timezone == "Pacific/Kosrae"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Kosrae</option>
                                                    <option value="Pacific/Norfolk" <?php if($data->timezone == "Pacific/Norfolk"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Norfolk</option>
                                                    <option value="Pacific/Noumea" <?php if($data->timezone == "Pacific/Noumea"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Noumea</option>
                                                    <option value="Pacific/Pohnpei" <?php if($data->timezone == "Pacific/Pohnpei"): ?> selected <?php endif; ?>>(UTC +11:00) Pacific/Pohnpei</option>
                                                    <option value="Asia/Anadyr" <?php if($data->timezone == "Asia/Anadyr"): ?> selected <?php endif; ?>>(UTC +12:00) Asia/Anadyr</option>
                                                    <option value="Asia/Kamchatka" <?php if($data->timezone == "Asia/Kamchatka"): ?> selected <?php endif; ?>>(UTC +12:00) Asia/Kamchatka</option>
                                                    <option value="Pacific/Funafuti" <?php if($data->timezone == "Pacific/Funafuti"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Funafuti</option>
                                                    <option value="Pacific/Kwajalein" <?php if($data->timezone == "Pacific/Kwajalein"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Kwajalein</option>
                                                    <option value="Pacific/Majuro" <?php if($data->timezone == "Pacific/Majuro"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Majuro</option>
                                                    <option value="Pacific/Nauru" <?php if($data->timezone == "Pacific/Nauru"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Nauru</option>
                                                    <option value="Pacific/Tarawa" <?php if($data->timezone == "Pacific/Tarawa"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Tarawa</option>
                                                    <option value="Pacific/Wake" <?php if($data->timezone == "Pacific/Wake"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Wake</option>
                                                    <option value="Pacific/Wallis" <?php if($data->timezone == "Pacific/Wallis"): ?> selected <?php endif; ?>>(UTC +12:00) Pacific/Wallis</option>
                                                    <option value="Antarctica/McMurdo" <?php if($data->timezone == "Antarctica/McMurdo"): ?> selected <?php endif; ?>>(UTC +13:00) Antarctica/McMurdo</option>
                                                    <option value="Pacific/Auckland" <?php if($data->timezone == "Pacific/Auckland"): ?> selected <?php endif; ?>>(UTC +13:00) Pacific/Auckland</option>
                                                    <option value="Pacific/Enderbury" <?php if($data->timezone == "Pacific/Enderbury"): ?> selected <?php endif; ?>>(UTC +13:00) Pacific/Enderbury</option>
                                                    <option value="Pacific/Fakaofo" <?php if($data->timezone == "Pacific/Fakaofo"): ?> selected <?php endif; ?>>(UTC +13:00) Pacific/Fakaofo</option>
                                                    <option value="Pacific/Fiji" <?php if($data->timezone == "Pacific/Fiji"): ?> selected <?php endif; ?>>(UTC +13:00) Pacific/Fiji</option>
                                                    <option value="Pacific/Chatham" <?php if($data->timezone == "Pacific/Chatham"): ?> selected <?php endif; ?>>(UTC +13:45) Pacific/Chatham</option>
                                                    <option value="Pacific/Apia" <?php if($data->timezone == "Pacific/Apia"): ?> selected <?php endif; ?>>(UTC +14:00) Pacific/Apia</option>
                                                    <option value="Pacific/Kiritimati" <?php if($data->timezone == "Pacific/Kiritimati"): ?> selected <?php endif; ?>>(UTC +14:00) Pacific/Kiritimati</option>
                                                    <option value="Pacific/Tongatapu" <?php if($data->timezone == "Pacific/Tongatapu"): ?> selected <?php endif; ?>>(UTC +14:00) Pacific/Tongatapu</option>
                                                </select>
                                            </div>
                                            
                                            <div class="eight wide field">
                                                <h2 class="ui small header"><?php echo e(__("Time format")); ?>

                                                    <div class="sub header"><?php echo e(__("Select your preffered time format")); ?></div>
                                                </h2>
                                                <select name="time_format" class="ui dropdown uppercase">
                                                    <option value="">Select format</option>
                                                    <option value="1" <?php if(isset($data->time_format)): ?> <?php if($data->time_format == 1): ?> selected <?php endif; ?> <?php endif; ?>>12 Hour (6:20 pm)</option>
                                                    <option value="2" <?php if(isset($data->time_format)): ?> <?php if($data->time_format == 2): ?> selected <?php endif; ?> <?php endif; ?>>24 Hour (16:20)</option>
                                                </select>
                                            </div>

                                            <h4 class="ui dividing header"><?php echo e(__("Optional Features")); ?></h4>

                                            <div class="eight wide field">
                                                <h2 class="ui small header"><?php echo e(__("RFID Clock In and Clock Out")); ?>

                                                    <div class="sub header"><?php echo e(__("Turn on to enable features for RFID Web Clock In and Clock Out")); ?></div>
                                                </h2>
                                                <div class="ui toggle checkbox ">
                                                  <input type="checkbox" name="rfid" <?php if(isset($data->rfid)): ?><?php if($data->rfid == "on"): ?> checked <?php endif; ?> <?php endif; ?>>
                                                  <label>Toggle Off/On</label>
                                                </div>
                                            </div>

                                            <div class="eight wide field">
                                                <h2 class="ui small header"><?php echo e(__("Time In comments")); ?>

                                                    <div class="sub header"><?php echo e(__("Turn on to require comments when clocking in")); ?></div>
                                                </h2>
                                                <div class="ui toggle checkbox ">
                                                  <input type="checkbox" name="clock_comment" <?php if(isset($data->clock_comment)): ?><?php if($data->clock_comment == "on"): ?> checked <?php endif; ?> <?php endif; ?>>
                                                  <label>Toggle Off/On</label>
                                                </div>
                                            </div>
                                            
                                            <h4 class="ui dividing header"><?php echo e(__("Safeguarding")); ?></h4>

                                            <div class="eight wide field">
                                                <h2 class="ui small header"><?php echo e(__("Web clock IP restriction")); ?>

                                                    <div class="sub header"><?php echo e(__("Turn on to block clocking from unknown device or IP address")); ?></div>
                                                </h2>
                                                <textarea name="iprestriction" rows="3" placeholder="<?php echo e(__("Enter IP addresses, if more than one add comma after each IP address")); ?>"><?php if(isset($data->iprestriction)): ?><?php echo e($data->iprestriction); ?><?php endif; ?></textarea>
                                            </div>
                                    </div>
                                    <div class="actions align-left">
                                        <button class="ui positive small button approve" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Save")); ?></button>
                                    </div>
                                    </form> 
                            </div>
                        </div>
                    </div>

                    <div class="ui tab" data-tab="about">
                        <div class="col-md-12">
                            <div class="tab-content">
                                <p class="license col-md-6" style="margin-bottom:0">
                                    <h3 style="margin-top:0" class="ui header">Workday a time clock application for employees</h3>
                                    <p>Easily track and manage employee work hours on jobs, improve your payroll process and collaborate with your timekeeping employees like never before.</p>
                                    <h4 class="ui header">Features</h4>
                                    <ul>
                                        <li>Employee Management (HRIS)</li>
                                        <li>Time and Attendance Management</li>
                                        <li>Employee Time Tracking</li>
                                        <li>Shift Management</li>
                                        <li>Leave Management</li>
                                        <li>Reporting and Analytics</li>
                                        <li>Multi-company</li>
                                        <li>Manager and Employee self-service</li>
                                    </ul>
                                    <div class="footer-text">
                                        <div class="sub header">Copyright (c) 2023 Codefactor. All rights reserved.</div>
                                    </div>
                                </p>
                                <div class="ui section divider"></div>
                               
                            </div>
                        </div>
                    </div>

                   

                </div>
            </div>

            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $('.menu .item').tab();
    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/settings.blade.php ENDPATH**/ ?>