    <?php $__env->startSection('meta'); ?>
        <title>Change Password | Workday Time Clock</title>
        <meta name="description" content="Workday change your password.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__("Change Password")); ?></h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="box box-success">
                    <div class="box-content">
                    <?php if($errors->any()): ?>
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                        <ul class="list">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('user/update-password')); ?>" class="ui form" method="post" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="field">
                            <label><?php echo e(__("Current Password")); ?></label>
                            <input type="password" name="currentpassword" value="" placeholder="Enter Current Password">
                        </div>
                        <div class="field">
                            <label for=""><?php echo e(__("New Password")); ?></label>
                            <input type="password" name="newpassword" value="" placeholder="Enter Password">
                        </div>
                        <div class="field">
                            <label for=""><?php echo e(__("Confirm Password")); ?></label>
                            <input type="password" name="confirmpassword" value="" placeholder="Enter Password Confirmation">
                        </div>
                    </div>
                    <div class="box-footer">
                        <button class="ui positive button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Update")); ?></button>
                        <a class="ui grey button" href="<?php echo e(url('dashboard')); ?>"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/update-password.blade.php ENDPATH**/ ?>